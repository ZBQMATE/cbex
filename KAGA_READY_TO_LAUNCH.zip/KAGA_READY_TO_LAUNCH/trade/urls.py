from django.urls import path
from . import views

app_name = 'trade'

urlpatterns = [
	path('', views.index, name = 'index'),
	path('NewUser/', views.sign_up_guide, name = 'sign_up_guide'),
	path('Register/', views.create_account, name = 'create_account'),
	path('Market/', views.trade_center, name = 'trade_center'),
	path('UserInfo/', views.account_manage, name = 'account_manage'),
	path('Logout/', views.sign_out, name = 'sign_out'),
	path('Withdraw/', views.withdraw, name = 'withdraw'),
	path('NewPw/', views.change_password, name = 'change_password'),
	path('PannelA1/', views.ak_order, name = 'ak_order'),
	path('PannelA2/', views.aa_order, name = 'aa_order'),
	path('PannelA3/', views.as_order, name = 'as_order'),
	path('PannelA4/', views.au_order, name = 'au_order'),
	path('PannelB1/', views.bk_order, name = 'bk_order'),
	path('PannelB2/', views.ba_order, name = 'ba_order'),
	path('PannelB3/', views.bs_order, name = 'bs_order'),
	path('PannelB4/', views.bu_order, name = 'bu_order'),
	path('TradeA1/', views.ak_process_order, name = 'ak_process_order'),
	path('TradeA2/', views.aa_process_order, name = 'aa_process_order'),
	path('TradeA3/', views.as_process_order, name = 'as_process_order'),
	path('TradeA4/', views.au_process_order, name = 'au_process_order'),
	path('TradeB1/', views.bk_process_order, name = 'bk_process_order'),
	path('TradeB2/', views.ba_process_order, name = 'ba_process_order'),
	path('TradeB3/', views.bs_process_order, name = 'bs_process_order'),
	path('TradeB4/', views.bu_process_order, name = 'bu_process_order'),
	path('RemoveA1/', views.ak_cancel_order, name = 'ak_cancel_order'),
	path('RemoveA2/', views.aa_cancel_order, name = 'aa_cancel_order'),
	path('RemoveA3/', views.as_cancel_order, name = 'as_cancel_order'),
	path('RemoveA4/', views.au_cancel_order, name = 'au_cancel_order'),
	path('RemoveB1/', views.bk_cancel_order, name = 'bk_cancel_order'),
	path('RemoveB2/', views.ba_cancel_order, name = 'ba_cancel_order'),
	path('RemoveB3/', views.bs_cancel_order, name = 'bs_cancel_order'),
	path('RemoveB4/', views.bu_cancel_order, name = 'bu_cancel_order'),
]