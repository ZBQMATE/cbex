from django.db import models

# Create your models here.
'''
CLIENT
_sell_pending, _buy_pending, _trade_deal, _orderbook, _history
for
AK, AA, AS, AU, BK, BA, BS, BU
'''


class client(models.Model):
	client_name = models.CharField(max_length = 100, unique = True)
	email_verify_code = models.CharField(max_length = 100)
	password_login = models.CharField(max_length = 100)
	password_trade = models.CharField(max_length = 100)
	asset_free = models.FloatField()
	asset_withdraw_pending = models.FloatField()
	asset_deal_pending = models.FloatField()
	pop_up_address = models.CharField(max_length = 200)
	
	
	
	
	
	
### AK
	
class ak_sell_pending(models.Model):
	ak_seller = models.ForeignKey(client, on_delete = models.CASCADE)
	ak_sell_price = models.FloatField()
	ak_sell_amount = models.IntegerField()
	ak_sell_maker_id = models.IntegerField()
	ak_sell_time = models.DateTimeField(auto_now = True)
	
class ak_buy_pending(models.Model):
	ak_buyer = models.ForeignKey(client, on_delete = models.CASCADE)
	ak_buy_price = models.FloatField()
	ak_buy_amount = models.IntegerField()
	ak_buy_maker_id = models.IntegerField()
	ak_buy_time = models.DateTimeField(auto_now = True)
	
class ak_trade_deal(models.Model):
	ak_trade_side = models.ManyToManyField(client)
	ak_trade_price = models.FloatField()
	ak_trade_amount = models.IntegerField()
	ak_trade_asker_id = models.IntegerField()
	ak_trade_asker_name = models.CharField(max_length = 100)
	ak_trade_bider_id = models.IntegerField()
	ak_trade_bider_name = models.CharField(max_length = 100)
	ak_trade_time = models.DateTimeField(auto_now = True)
	
class ak_orderbook(models.Model):
	# ask 10 and bid 10, order from high to low
	ak_orderbook_price = models.FloatField()
	ak_orderbook_amount = models.IntegerField()
	
class ak_history(models.Model):
	ak_actor = models.IntegerField()
	ak_action = models.CharField(max_length = 100)
	ak_price = models.FloatField()
	ak_amount = models.IntegerField()
	ak_act_time = models.DateTimeField(auto_now = True)
	
	
	
	
	
	
### AA
	
class aa_sell_pending(models.Model):
	aa_seller = models.ForeignKey(client, on_delete = models.CASCADE)
	aa_sell_price = models.FloatField()
	aa_sell_amount = models.IntegerField()
	aa_sell_maker_id = models.IntegerField()
	aa_sell_time = models.DateTimeField(auto_now = True)
	
class aa_buy_pending(models.Model):
	aa_buyer = models.ForeignKey(client, on_delete = models.CASCADE)
	aa_buy_price = models.FloatField()
	aa_buy_amount = models.IntegerField()
	aa_buy_maker_id = models.IntegerField()
	aa_buy_time = models.DateTimeField(auto_now = True)
	
class aa_trade_deal(models.Model):
	aa_trade_side = models.ManyToManyField(client)
	aa_trade_price = models.FloatField()
	aa_trade_amount = models.IntegerField()
	aa_trade_asker_id = models.IntegerField()
	aa_trade_asker_name = models.CharField(max_length = 100)
	aa_trade_bider_id = models.IntegerField()
	aa_trade_bider_name = models.CharField(max_length = 100)
	aa_trade_time = models.DateTimeField(auto_now = True)
	
class aa_orderbook(models.Model):
	# ask 10 and bid 10, order from high to low
	aa_orderbook_price = models.FloatField()
	aa_orderbook_amount = models.IntegerField()
	
class aa_history(models.Model):
	aa_actor = models.IntegerField()
	aa_action = models.CharField(max_length = 100)
	aa_price = models.FloatField()
	aa_amount = models.IntegerField()
	aa_act_time = models.DateTimeField(auto_now = True)
	
	
	
	
	
	
### AS
	
class as_sell_pending(models.Model):
	as_seller = models.ForeignKey(client, on_delete = models.CASCADE)
	as_sell_price = models.FloatField()
	as_sell_amount = models.IntegerField()
	as_sell_maker_id = models.IntegerField()
	as_sell_time = models.DateTimeField(auto_now = True)
	
class as_buy_pending(models.Model):
	as_buyer = models.ForeignKey(client, on_delete = models.CASCADE)
	as_buy_price = models.FloatField()
	as_buy_amount = models.IntegerField()
	as_buy_maker_id = models.IntegerField()
	as_buy_time = models.DateTimeField(auto_now = True)
	
class as_trade_deal(models.Model):
	as_trade_side = models.ManyToManyField(client)
	as_trade_price = models.FloatField()
	as_trade_amount = models.IntegerField()
	as_trade_asker_id = models.IntegerField()
	as_trade_asker_name = models.CharField(max_length = 100)
	as_trade_bider_id = models.IntegerField()
	as_trade_bider_name = models.CharField(max_length = 100)
	as_trade_time = models.DateTimeField(auto_now = True)
	
class as_orderbook(models.Model):
	# ask 10 and bid 10, order from high to low
	as_orderbook_price = models.FloatField()
	as_orderbook_amount = models.IntegerField()
	
class as_history(models.Model):
	as_actor = models.IntegerField()
	as_action = models.CharField(max_length = 100)
	as_price = models.FloatField()
	as_amount = models.IntegerField()
	as_act_time = models.DateTimeField(auto_now = True)
	
	
	
	
	
	
### AU
	
class au_sell_pending(models.Model):
	au_seller = models.ForeignKey(client, on_delete = models.CASCADE)
	au_sell_price = models.FloatField()
	au_sell_amount = models.IntegerField()
	au_sell_maker_id = models.IntegerField()
	au_sell_time = models.DateTimeField(auto_now = True)
	
class au_buy_pending(models.Model):
	au_buyer = models.ForeignKey(client, on_delete = models.CASCADE)
	au_buy_price = models.FloatField()
	au_buy_amount = models.IntegerField()
	au_buy_maker_id = models.IntegerField()
	au_buy_time = models.DateTimeField(auto_now = True)
	
class au_trade_deal(models.Model):
	au_trade_side = models.ManyToManyField(client)
	au_trade_price = models.FloatField()
	au_trade_amount = models.IntegerField()
	au_trade_asker_id = models.IntegerField()
	au_trade_asker_name = models.CharField(max_length = 100)
	au_trade_bider_id = models.IntegerField()
	au_trade_bider_name = models.CharField(max_length = 100)
	au_trade_time = models.DateTimeField(auto_now = True)
	
class au_orderbook(models.Model):
	# ask 10 and bid 10, order from high to low
	au_orderbook_price = models.FloatField()
	au_orderbook_amount = models.IntegerField()
	
class au_history(models.Model):
	au_actor = models.IntegerField()
	au_action = models.CharField(max_length = 100)
	au_price = models.FloatField()
	au_amount = models.IntegerField()
	au_act_time = models.DateTimeField(auto_now = True)
	
	
	
	
	
	
### BK
	
class bk_sell_pending(models.Model):
	bk_seller = models.ForeignKey(client, on_delete = models.CASCADE)
	bk_sell_price = models.FloatField()
	bk_sell_amount = models.IntegerField()
	bk_sell_maker_id = models.IntegerField()
	bk_sell_time = models.DateTimeField(auto_now = True)
	
class bk_buy_pending(models.Model):
	bk_buyer = models.ForeignKey(client, on_delete = models.CASCADE)
	bk_buy_price = models.FloatField()
	bk_buy_amount = models.IntegerField()
	bk_buy_maker_id = models.IntegerField()
	bk_buy_time = models.DateTimeField(auto_now = True)
	
class bk_trade_deal(models.Model):
	bk_trade_side = models.ManyToManyField(client)
	bk_trade_price = models.FloatField()
	bk_trade_amount = models.IntegerField()
	bk_trade_asker_id = models.IntegerField()
	bk_trade_asker_name = models.CharField(max_length = 100)
	bk_trade_bider_id = models.IntegerField()
	bk_trade_bider_name = models.CharField(max_length = 100)
	bk_trade_time = models.DateTimeField(auto_now = True)
	
class bk_orderbook(models.Model):
	# ask 10 and bid 10, order from high to low
	bk_orderbook_price = models.FloatField()
	bk_orderbook_amount = models.IntegerField()
	
class bk_history(models.Model):
	bk_actor = models.IntegerField()
	bk_action = models.CharField(max_length = 100)
	bk_price = models.FloatField()
	bk_amount = models.IntegerField()
	bk_act_time = models.DateTimeField(auto_now = True)
	
	
	
	
	
	
### BA
	
class ba_sell_pending(models.Model):
	ba_seller = models.ForeignKey(client, on_delete = models.CASCADE)
	ba_sell_price = models.FloatField()
	ba_sell_amount = models.IntegerField()
	ba_sell_maker_id = models.IntegerField()
	ba_sell_time = models.DateTimeField(auto_now = True)
	
class ba_buy_pending(models.Model):
	ba_buyer = models.ForeignKey(client, on_delete = models.CASCADE)
	ba_buy_price = models.FloatField()
	ba_buy_amount = models.IntegerField()
	ba_buy_maker_id = models.IntegerField()
	ba_buy_time = models.DateTimeField(auto_now = True)
	
class ba_trade_deal(models.Model):
	ba_trade_side = models.ManyToManyField(client)
	ba_trade_price = models.FloatField()
	ba_trade_amount = models.IntegerField()
	ba_trade_asker_id = models.IntegerField()
	ba_trade_asker_name = models.CharField(max_length = 100)
	ba_trade_bider_id = models.IntegerField()
	ba_trade_bider_name = models.CharField(max_length = 100)
	ba_trade_time = models.DateTimeField(auto_now = True)
	
class ba_orderbook(models.Model):
	# ask 10 and bid 10, order from high to low
	ba_orderbook_price = models.FloatField()
	ba_orderbook_amount = models.IntegerField()
	
class ba_history(models.Model):
	ba_actor = models.IntegerField()
	ba_action = models.CharField(max_length = 100)
	ba_price = models.FloatField()
	ba_amount = models.IntegerField()
	ba_act_time = models.DateTimeField(auto_now = True)
	
	
	
	
	
	
### BS
	
class bs_sell_pending(models.Model):
	bs_seller = models.ForeignKey(client, on_delete = models.CASCADE)
	bs_sell_price = models.FloatField()
	bs_sell_amount = models.IntegerField()
	bs_sell_maker_id = models.IntegerField()
	bs_sell_time = models.DateTimeField(auto_now = True)
	
class bs_buy_pending(models.Model):
	bs_buyer = models.ForeignKey(client, on_delete = models.CASCADE)
	bs_buy_price = models.FloatField()
	bs_buy_amount = models.IntegerField()
	bs_buy_maker_id = models.IntegerField()
	bs_buy_time = models.DateTimeField(auto_now = True)
	
class bs_trade_deal(models.Model):
	bs_trade_side = models.ManyToManyField(client)
	bs_trade_price = models.FloatField()
	bs_trade_amount = models.IntegerField()
	bs_trade_asker_id = models.IntegerField()
	bs_trade_asker_name = models.CharField(max_length = 100)
	bs_trade_bider_id = models.IntegerField()
	bs_trade_bider_name = models.CharField(max_length = 100)
	bs_trade_time = models.DateTimeField(auto_now = True)
	
class bs_orderbook(models.Model):
	# ask 10 and bid 10, order from high to low
	bs_orderbook_price = models.FloatField()
	bs_orderbook_amount = models.IntegerField()
	
class bs_history(models.Model):
	bs_actor = models.IntegerField()
	bs_action = models.CharField(max_length = 100)
	bs_price = models.FloatField()
	bs_amount = models.IntegerField()
	bs_act_time = models.DateTimeField(auto_now = True)
	
	
	
	
	
	
### BU
	
class bu_sell_pending(models.Model):
	bu_seller = models.ForeignKey(client, on_delete = models.CASCADE)
	bu_sell_price = models.FloatField()
	bu_sell_amount = models.IntegerField()
	bu_sell_maker_id = models.IntegerField()
	bu_sell_time = models.DateTimeField(auto_now = True)
	
class bu_buy_pending(models.Model):
	bu_buyer = models.ForeignKey(client, on_delete = models.CASCADE)
	bu_buy_price = models.FloatField()
	bu_buy_amount = models.IntegerField()
	bu_buy_maker_id = models.IntegerField()
	bu_buy_time = models.DateTimeField(auto_now = True)
	
class bu_trade_deal(models.Model):
	bu_trade_side = models.ManyToManyField(client)
	bu_trade_price = models.FloatField()
	bu_trade_amount = models.IntegerField()
	bu_trade_asker_id = models.IntegerField()
	bu_trade_asker_name = models.CharField(max_length = 100)
	bu_trade_bider_id = models.IntegerField()
	bu_trade_bider_name = models.CharField(max_length = 100)
	bu_trade_time = models.DateTimeField(auto_now = True)
	
class bu_orderbook(models.Model):
	# ask 10 and bid 10, order from high to low
	bu_orderbook_price = models.FloatField()
	bu_orderbook_amount = models.IntegerField()
	
class bu_history(models.Model):
	bu_actor = models.IntegerField()
	bu_action = models.CharField(max_length = 100)
	bu_price = models.FloatField()
	bu_amount = models.IntegerField()
	bu_act_time = models.DateTimeField(auto_now = True)
	
	
	