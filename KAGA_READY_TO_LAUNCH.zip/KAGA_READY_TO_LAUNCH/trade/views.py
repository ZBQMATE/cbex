import hashlib
from django.shortcuts import render, get_object_or_404
from django.template import loader
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.urls import reverse
from django.db import transaction
from .models import client, ak_sell_pending, ak_buy_pending, ak_trade_deal, ak_orderbook, ak_history, aa_sell_pending, aa_buy_pending, aa_trade_deal, aa_orderbook, aa_history, as_sell_pending, as_buy_pending, as_trade_deal, as_orderbook, as_history, au_sell_pending, au_buy_pending, au_trade_deal, au_orderbook, au_history, bk_sell_pending, bk_buy_pending, bk_trade_deal, bk_orderbook, bk_history, ba_sell_pending, ba_buy_pending, ba_trade_deal, ba_orderbook, ba_history, bs_sell_pending, bs_buy_pending, bs_trade_deal, bs_orderbook, bs_history, bu_sell_pending, bu_buy_pending, bu_trade_deal, bu_orderbook, bu_history
from .forms import login_form, signup_form, withdraw_form, changepw_form, order_form, cancel_form

### when visit the site, show login page or direct to how to sign up page
def index(request):
	if 'uid' in request.session:
		return HttpResponseRedirect(reverse('trade:trade_center'))
	if request.method == 'POST':
		form = login_form(request.POST)
		if form.is_valid():
			login_name = form.cleaned_data['usernamefld']
			login_password = form.cleaned_data['passwordfld']
			try:
				user_indb = client.objects.get(client_name = login_name)
			except client.DoesNotExist:
				info = "INCORRECT USER NAME OR PASSWORD"
				return render(request, 'trade/index.html', {'form': form, 'info': info,})
			else:
				mid_sig_pw = hashlib.md5(login_password.encode("utf8")).hexdigest().upper() + user_indb.email_verify_code
				signed_pw = hashlib.sha256(mid_sig_pw.encode("utf8")).hexdigest()
				if user_indb.password_login != signed_pw:
					info = "INCORRECT USER NAME OR PASSWORD"
					return render(request, 'trade/index.html', {'form': form, 'info': info,})
				if user_indb.password_login == signed_pw:
					request.session['uid'] = login_name
					return HttpResponseRedirect(reverse('trade:trade_center'))
		else:
			return render(request, 'trade/index.html', {'form': form,})
	form = login_form()
	return render(request, 'trade/index.html', {'form': form,})
	
	
### show sign up page, this is dead link
def sign_up_guide(request):
	return render(request, 'trade/signupguide.html')
	
	
### create an account, input verify code, pw1, pw2, name
def create_account(request):
	if 'uid' in request.session:
		info = "You are already signed in. You can start trade now."
		form = signup_form()
		return render(request, 'trade/signup.html', {'form': form, 'info': info})
	if request.method == 'POST':
		form = signup_form(request.POST)
		if form.is_valid():
			email_code = form.cleaned_data['verifycodefld']
			signup_name = form.cleaned_data['usernamefld']
			signup_password = form.cleaned_data['passwordfld']
			signup_token = form.cleaned_data['tradetokenfld']
			try:
				user_position = client.objects.get(email_verify_code = email_code)
			except client.DoesNotExist:
				info = "NOT A VALID EMAIL CODE"
				return render(request, 'trade/signup.html', {'form': form, 'info': info})
			else:
				if user_position.password_login != "evergrand":
					info = "NOT A VALID EMAIL CODE"
					return render(request, 'trade/signup.html', {'form': form, 'info': info})
				if user_position.password_login == "evergrand":
					try:
						same_name_user = client.objects.get(client_name = signup_name)
					except client.DoesNotExist:
						pass
					else:
						info = "THIS USER NAME IS TAKEN"
						return render(request, 'trade/signup.html', {'form': form, 'info': info})
					# hash password and trade token
					mid_sig_pw = hashlib.md5(signup_password.encode("utf8")).hexdigest().upper() + user_position.email_verify_code
					signed_pw = hashlib.sha256(mid_sig_pw.encode("utf8")).hexdigest()
					mid_sig_pin = hashlib.md5(signup_token.encode("utf8")).hexdigest().upper() + user_position.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					with transaction.atomic():
						user_position.client_name = signup_name
						user_position.password_login = signed_pw
						user_position.password_trade = signed_pin
						user_position.asset_free = 0
						user_position.asset_withdraw_pending = 0
						user_position.asset_deal_pending = 0
						user_position.save()
					request.session['uid'] = signup_name
					return HttpResponseRedirect(reverse('trade:trade_center'))
		else:
			return render(request, 'trade/signup.html', {'form': form,})
	form = signup_form()
	return render(request, 'trade/signup.html', {'form': form,})
	
	
### trade center, direct to option market and account manage
def trade_center(request):
	is_login = False
	cur_user = ""
	if 'uid' in request.session:
		is_login = True
		cur_user = request.session['uid']
	AK_ask = ak_orderbook.objects.get(pk = 10)
	AK_bid = ak_orderbook.objects.get(pk = 11)
	AA_ask = aa_orderbook.objects.get(pk = 10)
	AA_bid = aa_orderbook.objects.get(pk = 11)
	AS_ask = as_orderbook.objects.get(pk = 10)
	AS_bid = as_orderbook.objects.get(pk = 11)
	AU_ask = au_orderbook.objects.get(pk = 10)
	AU_bid = au_orderbook.objects.get(pk = 11)
	BK_ask = bk_orderbook.objects.get(pk = 10)
	BK_bid = bk_orderbook.objects.get(pk = 11)
	BA_ask = ba_orderbook.objects.get(pk = 10)
	BA_bid = ba_orderbook.objects.get(pk = 11)
	BS_ask = bs_orderbook.objects.get(pk = 10)
	BS_bid = bs_orderbook.objects.get(pk = 11)
	BU_ask = bu_orderbook.objects.get(pk = 10)
	BU_bid = bu_orderbook.objects.get(pk = 11)
	return render(request, 'trade/tradecenter.html', {'is_login': is_login, 'cur_user': cur_user, 'AK_ask': AK_ask, 'AK_bid': AK_bid, 'AA_ask': AA_ask, 'AA_bid': AA_bid, 'AS_ask': AS_ask, 'AS_bid': AS_bid, 'AU_ask': AU_ask, 'AU_bid': AU_bid, 'BK_ask': BK_ask, 'BK_bid': BK_bid, 'BA_ask': BA_ask, 'BA_bid': BA_bid, 'BS_ask': BS_ask, 'BS_bid': BS_bid, 'BU_ask': BU_ask, 'BU_bid': BU_bid})
	
	
### account manage page, pop up, withdraw, change password and show deals
def account_manage(request):
	if 'uid' in request.session:
		try:
			cur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			ak_user_deal = cur_user.ak_trade_deal_set.all()
			aa_user_deal = cur_user.aa_trade_deal_set.all()
			as_user_deal = cur_user.as_trade_deal_set.all()
			au_user_deal = cur_user.au_trade_deal_set.all()
			bk_user_deal = cur_user.bk_trade_deal_set.all()
			ba_user_deal = cur_user.ba_trade_deal_set.all()
			bs_user_deal = cur_user.bs_trade_deal_set.all()
			bu_user_deal = cur_user.bu_trade_deal_set.all()
			return render(request, 'trade/account.html', {'usr': cur_user, 'ak_deal_list': ak_user_deal, 'aa_deal_list': aa_user_deal, 'as_deal_list': as_user_deal, 'au_deal_list': au_user_deal, 'bk_deal_list': bk_user_deal, 'ba_deal_list': ba_user_deal, 'bs_deal_list': bs_user_deal, 'bu_deal_list': bu_user_deal})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
### logout
def sign_out(request):
	if 'uid' in request.session:
		del request.session['uid']
	return HttpResponseRedirect(reverse('trade:index'))
	
	
### withdraw, need address and amount
def withdraw(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			if request.method == 'POST':
				form = withdraw_form(request.POST)
				if form.is_valid():
					withdraw_amount = form.cleaned_data['amountfld']
					user_token = form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						info = "INCORRECT TRADE PIN"
						return render(request, 'trade/withdraw.html', {'form': form, 'info': info})
					if withdraw_amount > ur_user.asset_free:
						info = "WITHDRAW AMOUNT EXCEEDS YOUR AVAILABLE BALANCE."
						return render(request, 'trade/withdraw.html', {'form': form, 'info': info})
					if ur_user.password_trade == signed_pin and withdraw_amount <= ur_user.asset_free:
						# need a transaction here
						with transaction.atomic():
							ur_user.asset_free = ur_user.asset_free - withdraw_amount
							ur_user.asset_withdraw_pending = withdraw_amount + ur_user.asset_withdraw_pending
							ur_user.save()
						return HttpResponseRedirect(reverse('trade:account_manage'))
				else:
					return render(request, 'trade/withdraw.html', {'form': form})
			form = withdraw_form()
			return render(request, 'trade/withdraw.html', {'form': form})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
### change password page
def change_password(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			if request.method == 'POST':
				form = changepw_form(request.POST)
				if form.is_valid():
					new_login_pw = form.cleaned_data['newpwfld']
					user_token = form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						info = "INCORRECT TRADE PIN"
						return render(request, 'trade/changepw.html', {'form': form, 'info': info})
					if ur_user.password_trade == signed_pin:
						mid_sig_pw = hashlib.md5(new_login_pw.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
						signed_pw = hashlib.sha256(mid_sig_pw.encode("utf8")).hexdigest()
						ur_user.password_login = signed_pw
						ur_user.save()
						return HttpResponseRedirect(reverse('trade:account_manage'))
				else:
					return render(request, 'trade/changepw.html', {'form': form})
			form = changepw_form()
			return render(request, 'trade/changepw.html', {'form': form})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
### option order page, show order book and hanging bills
def ak_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = ak_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.ak_sell_pending_set.all()
			buy_pending = ur_user.ak_buy_pending_set.all()
			set_form = order_form()
			del_form = cancel_form()
			return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
def aa_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = aa_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.aa_sell_pending_set.all()
			buy_pending = ur_user.aa_buy_pending_set.all()
			set_form = order_form()
			del_form = cancel_form()
			return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
def as_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = as_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.as_sell_pending_set.all()
			buy_pending = ur_user.as_buy_pending_set.all()
			set_form = order_form()
			del_form = cancel_form()
			return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
def au_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = au_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.au_sell_pending_set.all()
			buy_pending = ur_user.au_buy_pending_set.all()
			set_form = order_form()
			del_form = cancel_form()
			return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
def bk_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = bk_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.bk_sell_pending_set.all()
			buy_pending = ur_user.bk_buy_pending_set.all()
			set_form = order_form()
			del_form = cancel_form()
			return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
def ba_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = ba_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.ba_sell_pending_set.all()
			buy_pending = ur_user.ba_buy_pending_set.all()
			set_form = order_form()
			del_form = cancel_form()
			return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
def bs_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = bs_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.bs_sell_pending_set.all()
			buy_pending = ur_user.bs_buy_pending_set.all()
			set_form = order_form()
			del_form = cancel_form()
			return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
def bu_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = bu_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.bu_sell_pending_set.all()
			buy_pending = ur_user.bu_buy_pending_set.all()
			set_form = order_form()
			del_form = cancel_form()
			return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
### CORE, process posted order
@transaction.atomic
def ak_process_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = ak_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.ak_sell_pending_set.all()
			buy_pending = ur_user.ak_buy_pending_set.all()
			del_form = cancel_form()
			if request.method == 'POST':
				#check google recaptcha later
				set_form = order_form(request.POST)
				if set_form.is_valid():
					ord_amount = set_form.cleaned_data['orderamountfld']
					ord_price = set_form.cleaned_data['orderpricefld']
					ord_direction = set_form.cleaned_data['orderdirection']
					user_token = set_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						info = "INCORRECT TRADE PIN"
						return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
					if ur_user.password_trade == signed_pin:
						#sell
						if ord_direction == '1':
							#need transaction later
							if ord_amount > ur_user.asset_free * 100:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_amount <= ur_user.asset_free * 100:
								ur_user.asset_free = ur_user.asset_free - ord_amount / 100
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_amount / 100
								ur_user.save()
								sell_qualify_list = ak_buy_pending.objects.all().filter(ak_buy_price__gte = ord_price).order_by('-ak_buy_price')#high to low
								if sell_qualify_list.count() == 0:
									this_sell_order = ak_sell_pending(ak_seller = ur_user, ak_sell_price = ord_price, ak_sell_amount = ord_amount, ak_sell_maker_id = ur_user.id)
									this_sell_order.save()
								if sell_qualify_list.count() > 0:
									rest_sell_amount = ord_amount
									for buy_bill in sell_qualify_list:
										if buy_bill.ak_buy_amount > rest_sell_amount:
											buy_bill.ak_buy_amount = buy_bill.ak_buy_amount - rest_sell_amount
											buy_bill.save()
											new_position = ak_trade_deal(ak_trade_price = ord_price, ak_trade_amount = rest_sell_amount, ak_trade_asker_id = ur_user.id, ak_trade_asker_name = ur_user.client_name, ak_trade_bider_id = buy_bill.ak_buyer.id, ak_trade_bider_name = buy_bill.ak_buyer.client_name)
											new_position.save()
											new_position.ak_trade_side.add(buy_bill.ak_buyer, ur_user)
											rest_sell_amount = 0
											break
										if buy_bill.ak_buy_amount == rest_sell_amount:
											new_position = ak_trade_deal(ak_trade_price = ord_price, ak_trade_amount = rest_sell_amount, ak_trade_asker_id = ur_user.id, ak_trade_asker_name = ur_user.client_name, ak_trade_bider_id = buy_bill.ak_buyer.id, ak_trade_bider_name = buy_bill.ak_buyer.client_name)
											new_position.save()
											new_position.ak_trade_side.add(buy_bill.ak_buyer, ur_user)
											buy_bill.delete()
											rest_sell_amount = 0
											break
										if buy_bill.ak_buy_amount < rest_sell_amount:
											rest_sell_amount = rest_sell_amount - buy_bill.ak_buy_amount
											new_position = ak_trade_deal(ak_trade_price = ord_price, ak_trade_amount = buy_bill.ak_buy_amount, ak_trade_asker_id = ur_user.id, ak_trade_asker_name = ur_user.client_name, ak_trade_bider_id = buy_bill.ak_buyer.id, ak_trade_bider_name = buy_bill.ak_buyer.client_name)
											new_position.save()
											new_position.ak_trade_side.add(buy_bill.ak_buyer, ur_user)
											buy_bill.delete()
									if rest_sell_amount > 0:
										this_sell_order = ak_sell_pending(ak_seller = ur_user, ak_sell_price = ord_price, ak_sell_amount = rest_sell_amount, ak_sell_maker_id = ur_user.id)
										this_sell_order.save()
								sell_pending = ur_user.ak_sell_pending_set.all()
						
						#buy
						if ord_direction == '2':
							#need transaction later
							if ord_price * ord_amount > ur_user.asset_free:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_price * ord_amount <= ur_user.asset_free:
								ur_user.asset_free = ur_user.asset_free - ord_price * ord_amount
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_price * ord_amount
								ur_user.save()
								buy_qualify_list = ak_sell_pending.objects.all().filter(ak_sell_price__lte = ord_price).order_by('ak_sell_price')#low to high
								if buy_qualify_list.count() == 0:
									this_buy_order = ak_buy_pending(ak_buyer = ur_user, ak_buy_price = ord_price, ak_buy_amount = ord_amount, ak_buy_maker_id = ur_user.id)
									this_buy_order.save()
								if buy_qualify_list.count() > 0:
									rest_buy_amount = ord_amount
									for sell_bill in buy_qualify_list:
										if sell_bill.ak_sell_amount > rest_buy_amount:
											sell_bill.ak_sell_amount = sell_bill.ak_sell_amount - rest_buy_amount
											sell_bill.save()
											new_position = ak_trade_deal(ak_trade_price = ord_price, ak_trade_amount = rest_buy_amount, ak_trade_asker_id = sell_bill.ak_seller.id, ak_trade_asker_name = sell_bill.ak_seller.client_name, ak_trade_bider_id = ur_user.id, ak_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.ak_trade_side.add(ur_user, sell_bill.ak_seller)
											rest_buy_amount = 0
											break
										if sell_bill.ak_sell_amount == rest_buy_amount:
											new_position = ak_trade_deal(ak_trade_price = ord_price, ak_trade_amount = rest_buy_amount, ak_trade_asker_id = sell_bill.ak_seller.id, ak_trade_asker_name = sell_bill.ak_seller.client_name, ak_trade_bider_id = ur_user.id, ak_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.ak_trade_side.add(ur_user, sell_bill.ak_seller)
											sell_bill.delete()
											rest_buy_amount = 0
											break
										if sell_bill.ak_sell_amount < rest_buy_amount:
											rest_buy_amount = rest_buy_amount - sell_bill.ak_sell_amount
											new_position = ak_trade_deal(ak_trade_price = ord_price, ak_trade_amount = sell_bill.ak_sell_amount, ak_trade_asker_id = sell_bill.ak_seller.id, ak_trade_asker_name = sell_bill.ak_seller.client_name, ak_trade_bider_id = ur_user.id, ak_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.ak_trade_side.add(ur_user, sell_bill.ak_seller)
											sell_bill.delete()
									if rest_buy_amount > 0:
										this_buy_order = ak_buy_pending(ak_buyer = ur_user, ak_buy_price = ord_price, ak_buy_amount = rest_buy_amount, ak_buy_maker_id = ur_user.id)
										this_buy_order.save()
								buy_pending = ur_user.ak_buy_pending_set.all()
						
						# add record
						new_record = ak_history(ak_actor = ur_user.id, ak_action = ord_direction, ak_price = ord_price, ak_amount = ord_amount)
						new_record.save()
						# refresh orderbook, maybe need a try: pass
						if (ord_direction == '1' and ord_price < orderbook_list[0].ak_orderbook_price) or (ord_direction == '2' and ord_price > orderbook_list[19].ak_orderbook_price):
							sell_orderbook = ak_sell_pending.objects.all().order_by('ak_sell_price')[:10]#low to high
							buy_orderbook = ak_buy_pending.objects.all().order_by('-ak_buy_price')[:10]#high to low
							num_sell = sell_orderbook.count()
							num_buy = buy_orderbook.count()
							for i in range(num_sell):
								tmp_orderbook_record = ak_orderbook.objects.get(pk = 10 - i)
								tmp_orderbook_record.ak_orderbook_price = sell_orderbook[i].ak_sell_price
								tmp_orderbook_record.ak_orderbook_amount = sell_orderbook[i].ak_sell_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_sell):
								tmp_orderbook_record = ak_orderbook.objects.get(pk = 10 - num_sell - i)
								tmp_orderbook_record.ak_orderbook_price = 0.01
								tmp_orderbook_record.ak_orderbook_amount = 0
								tmp_orderbook_record.save()
							for i in range(num_buy):
								tmp_orderbook_record = ak_orderbook.objects.get(pk = 11 + i)
								tmp_orderbook_record.ak_orderbook_price = buy_orderbook[i].ak_buy_price
								tmp_orderbook_record.ak_orderbook_amount = buy_orderbook[i].ak_buy_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_buy):
								tmp_orderbook_record = ak_orderbook.objects.get(pk = 11 + num_buy + i)
								tmp_orderbook_record.ak_orderbook_price = 0.0
								tmp_orderbook_record.ak_orderbook_amount = 0
								tmp_orderbook_record.save()
							orderbook_list = ak_orderbook.objects.all().order_by('id')
						
						info = "ORDER SUCCESSFULLY SUBMITTED"
						return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
						
				else:
					return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			set_form = order_form()
			return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def aa_process_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = aa_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.aa_sell_pending_set.all()
			buy_pending = ur_user.aa_buy_pending_set.all()
			del_form = cancel_form()
			if request.method == 'POST':
				#check google recaptcha later
				set_form = order_form(request.POST)
				if set_form.is_valid():
					ord_amount = set_form.cleaned_data['orderamountfld']
					ord_price = set_form.cleaned_data['orderpricefld']
					ord_direction = set_form.cleaned_data['orderdirection']
					user_token = set_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						info = "INCORRECT TRADE PIN"
						return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
					if ur_user.password_trade == signed_pin:
						#sell
						if ord_direction == '1':
							#need transaction later
							if ord_amount > ur_user.asset_free * 100:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_amount <= ur_user.asset_free * 100:
								ur_user.asset_free = ur_user.asset_free - ord_amount / 100
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_amount / 100
								ur_user.save()
								sell_qualify_list = aa_buy_pending.objects.all().filter(aa_buy_price__gte = ord_price).order_by('-aa_buy_price')#high to low
								if sell_qualify_list.count() == 0:
									this_sell_order = aa_sell_pending(aa_seller = ur_user, aa_sell_price = ord_price, aa_sell_amount = ord_amount, aa_sell_maker_id = ur_user.id)
									this_sell_order.save()
								if sell_qualify_list.count() > 0:
									rest_sell_amount = ord_amount
									for buy_bill in sell_qualify_list:
										if buy_bill.aa_buy_amount > rest_sell_amount:
											buy_bill.aa_buy_amount = buy_bill.aa_buy_amount - rest_sell_amount
											buy_bill.save()
											new_position = aa_trade_deal(aa_trade_price = ord_price, aa_trade_amount = rest_sell_amount, aa_trade_asker_id = ur_user.id, aa_trade_asker_name = ur_user.client_name, aa_trade_bider_id = buy_bill.aa_buyer.id, aa_trade_bider_name = buy_bill.aa_buyer.client_name)
											new_position.save()
											new_position.aa_trade_side.add(buy_bill.aa_buyer, ur_user)
											rest_sell_amount = 0
											break
										if buy_bill.aa_buy_amount == rest_sell_amount:
											new_position = aa_trade_deal(aa_trade_price = ord_price, aa_trade_amount = rest_sell_amount, aa_trade_asker_id = ur_user.id, aa_trade_asker_name = ur_user.client_name, aa_trade_bider_id = buy_bill.aa_buyer.id, aa_trade_bider_name = buy_bill.aa_buyer.client_name)
											new_position.save()
											new_position.aa_trade_side.add(buy_bill.aa_buyer, ur_user)
											buy_bill.delete()
											rest_sell_amount = 0
											break
										if buy_bill.aa_buy_amount < rest_sell_amount:
											rest_sell_amount = rest_sell_amount - buy_bill.aa_buy_amount
											new_position = aa_trade_deal(aa_trade_price = ord_price, aa_trade_amount = buy_bill.aa_buy_amount, aa_trade_asker_id = ur_user.id, aa_trade_asker_name = ur_user.client_name, aa_trade_bider_id = buy_bill.aa_buyer.id, aa_trade_bider_name = buy_bill.aa_buyer.client_name)
											new_position.save()
											new_position.aa_trade_side.add(buy_bill.aa_buyer, ur_user)
											buy_bill.delete()
									if rest_sell_amount > 0:
										this_sell_order = aa_sell_pending(aa_seller = ur_user, aa_sell_price = ord_price, aa_sell_amount = rest_sell_amount, aa_sell_maker_id = ur_user.id)
										this_sell_order.save()
								sell_pending = ur_user.aa_sell_pending_set.all()
						
						#buy
						if ord_direction == '2':
							#need transaction later
							if ord_price * ord_amount > ur_user.asset_free:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_price * ord_amount <= ur_user.asset_free:
								ur_user.asset_free = ur_user.asset_free - ord_price * ord_amount
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_price * ord_amount
								ur_user.save()
								buy_qualify_list = aa_sell_pending.objects.all().filter(aa_sell_price__lte = ord_price).order_by('aa_sell_price')#low to high
								if buy_qualify_list.count() == 0:
									this_buy_order = aa_buy_pending(aa_buyer = ur_user, aa_buy_price = ord_price, aa_buy_amount = ord_amount, aa_buy_maker_id = ur_user.id)
									this_buy_order.save()
								if buy_qualify_list.count() > 0:
									rest_buy_amount = ord_amount
									for sell_bill in buy_qualify_list:
										if sell_bill.aa_sell_amount > rest_buy_amount:
											sell_bill.aa_sell_amount = sell_bill.aa_sell_amount - rest_buy_amount
											sell_bill.save()
											new_position = aa_trade_deal(aa_trade_price = ord_price, aa_trade_amount = rest_buy_amount, aa_trade_asker_id = sell_bill.aa_seller.id, aa_trade_asker_name = sell_bill.aa_seller.client_name, aa_trade_bider_id = ur_user.id, aa_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.aa_trade_side.add(ur_user, sell_bill.aa_seller)
											rest_buy_amount = 0
											break
										if sell_bill.aa_sell_amount == rest_buy_amount:
											new_position = aa_trade_deal(aa_trade_price = ord_price, aa_trade_amount = rest_buy_amount, aa_trade_asker_id = sell_bill.aa_seller.id, aa_trade_asker_name = sell_bill.aa_seller.client_name, aa_trade_bider_id = ur_user.id, aa_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.aa_trade_side.add(ur_user, sell_bill.aa_seller)
											sell_bill.delete()
											rest_buy_amount = 0
											break
										if sell_bill.aa_sell_amount < rest_buy_amount:
											rest_buy_amount = rest_buy_amount - sell_bill.aa_sell_amount
											new_position = aa_trade_deal(aa_trade_price = ord_price, aa_trade_amount = sell_bill.aa_sell_amount, aa_trade_asker_id = sell_bill.aa_seller.id, aa_trade_asker_name = sell_bill.aa_seller.client_name, aa_trade_bider_id = ur_user.id, aa_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.aa_trade_side.add(ur_user, sell_bill.aa_seller)
											sell_bill.delete()
									if rest_buy_amount > 0:
										this_buy_order = aa_buy_pending(aa_buyer = ur_user, aa_buy_price = ord_price, aa_buy_amount = rest_buy_amount, aa_buy_maker_id = ur_user.id)
										this_buy_order.save()
								buy_pending = ur_user.aa_buy_pending_set.all()
						
						# add record
						new_record = aa_history(aa_actor = ur_user.id, aa_action = ord_direction, aa_price = ord_price, aa_amount = ord_amount)
						new_record.save()
						# refresh orderbook, maybe need a try: pass
						if (ord_direction == '1' and ord_price < orderbook_list[0].aa_orderbook_price) or (ord_direction == '2' and ord_price > orderbook_list[19].aa_orderbook_price):
							sell_orderbook = aa_sell_pending.objects.all().order_by('aa_sell_price')[:10]#low to high
							buy_orderbook = aa_buy_pending.objects.all().order_by('-aa_buy_price')[:10]#high to low
							num_sell = sell_orderbook.count()
							num_buy = buy_orderbook.count()
							for i in range(num_sell):
								tmp_orderbook_record = aa_orderbook.objects.get(pk = 10 - i)
								tmp_orderbook_record.aa_orderbook_price = sell_orderbook[i].aa_sell_price
								tmp_orderbook_record.aa_orderbook_amount = sell_orderbook[i].aa_sell_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_sell):
								tmp_orderbook_record = aa_orderbook.objects.get(pk = 10 - num_sell - i)
								tmp_orderbook_record.aa_orderbook_price = 0.01
								tmp_orderbook_record.aa_orderbook_amount = 0
								tmp_orderbook_record.save()
							for i in range(num_buy):
								tmp_orderbook_record = aa_orderbook.objects.get(pk = 11 + i)
								tmp_orderbook_record.aa_orderbook_price = buy_orderbook[i].aa_buy_price
								tmp_orderbook_record.aa_orderbook_amount = buy_orderbook[i].aa_buy_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_buy):
								tmp_orderbook_record = aa_orderbook.objects.get(pk = 11 + num_buy + i)
								tmp_orderbook_record.aa_orderbook_price = 0.0
								tmp_orderbook_record.aa_orderbook_amount = 0
								tmp_orderbook_record.save()
							orderbook_list = aa_orderbook.objects.all().order_by('id')
						
						info = "ORDER SUCCESSFULLY SUBMITTED"
						return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
						
				else:
					return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			set_form = order_form()
			return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def as_process_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = as_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.as_sell_pending_set.all()
			buy_pending = ur_user.as_buy_pending_set.all()
			del_form = cancel_form()
			if request.method == 'POST':
				#check google recaptcha later
				set_form = order_form(request.POST)
				if set_form.is_valid():
					ord_amount = set_form.cleaned_data['orderamountfld']
					ord_price = set_form.cleaned_data['orderpricefld']
					ord_direction = set_form.cleaned_data['orderdirection']
					user_token = set_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						info = "INCORRECT TRADE PIN"
						return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
					if ur_user.password_trade == signed_pin:
						#sell
						if ord_direction == '1':
							#need transaction later
							if ord_amount > ur_user.asset_free * 100:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_amount <= ur_user.asset_free * 100:
								ur_user.asset_free = ur_user.asset_free - ord_amount / 100
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_amount / 100
								ur_user.save()
								sell_qualify_list = as_buy_pending.objects.all().filter(as_buy_price__gte = ord_price).order_by('-as_buy_price')#high to low
								if sell_qualify_list.count() == 0:
									this_sell_order = as_sell_pending(as_seller = ur_user, as_sell_price = ord_price, as_sell_amount = ord_amount, as_sell_maker_id = ur_user.id)
									this_sell_order.save()
								if sell_qualify_list.count() > 0:
									rest_sell_amount = ord_amount
									for buy_bill in sell_qualify_list:
										if buy_bill.as_buy_amount > rest_sell_amount:
											buy_bill.as_buy_amount = buy_bill.as_buy_amount - rest_sell_amount
											buy_bill.save()
											new_position = as_trade_deal(as_trade_price = ord_price, as_trade_amount = rest_sell_amount, as_trade_asker_id = ur_user.id, as_trade_asker_name = ur_user.client_name, as_trade_bider_id = buy_bill.as_buyer.id, as_trade_bider_name = buy_bill.as_buyer.client_name)
											new_position.save()
											new_position.as_trade_side.add(buy_bill.as_buyer, ur_user)
											rest_sell_amount = 0
											break
										if buy_bill.as_buy_amount == rest_sell_amount:
											new_position = as_trade_deal(as_trade_price = ord_price, as_trade_amount = rest_sell_amount, as_trade_asker_id = ur_user.id, as_trade_asker_name = ur_user.client_name, as_trade_bider_id = buy_bill.as_buyer.id, as_trade_bider_name = buy_bill.as_buyer.client_name)
											new_position.save()
											new_position.as_trade_side.add(buy_bill.as_buyer, ur_user)
											buy_bill.delete()
											rest_sell_amount = 0
											break
										if buy_bill.as_buy_amount < rest_sell_amount:
											rest_sell_amount = rest_sell_amount - buy_bill.as_buy_amount
											new_position = as_trade_deal(as_trade_price = ord_price, as_trade_amount = buy_bill.as_buy_amount, as_trade_asker_id = ur_user.id, as_trade_asker_name = ur_user.client_name, as_trade_bider_id = buy_bill.as_buyer.id, as_trade_bider_name = buy_bill.as_buyer.client_name)
											new_position.save()
											new_position.as_trade_side.add(buy_bill.as_buyer, ur_user)
											buy_bill.delete()
									if rest_sell_amount > 0:
										this_sell_order = as_sell_pending(as_seller = ur_user, as_sell_price = ord_price, as_sell_amount = rest_sell_amount, as_sell_maker_id = ur_user.id)
										this_sell_order.save()
								sell_pending = ur_user.as_sell_pending_set.all()
						
						#buy
						if ord_direction == '2':
							#need transaction later
							if ord_price * ord_amount > ur_user.asset_free:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_price * ord_amount <= ur_user.asset_free:
								ur_user.asset_free = ur_user.asset_free - ord_price * ord_amount
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_price * ord_amount
								ur_user.save()
								buy_qualify_list = as_sell_pending.objects.all().filter(as_sell_price__lte = ord_price).order_by('as_sell_price')#low to high
								if buy_qualify_list.count() == 0:
									this_buy_order = as_buy_pending(as_buyer = ur_user, as_buy_price = ord_price, as_buy_amount = ord_amount, as_buy_maker_id = ur_user.id)
									this_buy_order.save()
								if buy_qualify_list.count() > 0:
									rest_buy_amount = ord_amount
									for sell_bill in buy_qualify_list:
										if sell_bill.as_sell_amount > rest_buy_amount:
											sell_bill.as_sell_amount = sell_bill.as_sell_amount - rest_buy_amount
											sell_bill.save()
											new_position = as_trade_deal(as_trade_price = ord_price, as_trade_amount = rest_buy_amount, as_trade_asker_id = sell_bill.as_seller.id, as_trade_asker_name = sell_bill.as_seller.client_name, as_trade_bider_id = ur_user.id, as_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.as_trade_side.add(ur_user, sell_bill.as_seller)
											rest_buy_amount = 0
											break
										if sell_bill.as_sell_amount == rest_buy_amount:
											new_position = as_trade_deal(as_trade_price = ord_price, as_trade_amount = rest_buy_amount, as_trade_asker_id = sell_bill.as_seller.id, as_trade_asker_name = sell_bill.as_seller.client_name, as_trade_bider_id = ur_user.id, as_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.as_trade_side.add(ur_user, sell_bill.as_seller)
											sell_bill.delete()
											rest_buy_amount = 0
											break
										if sell_bill.as_sell_amount < rest_buy_amount:
											rest_buy_amount = rest_buy_amount - sell_bill.as_sell_amount
											new_position = as_trade_deal(as_trade_price = ord_price, as_trade_amount = sell_bill.as_sell_amount, as_trade_asker_id = sell_bill.as_seller.id, as_trade_asker_name = sell_bill.as_seller.client_name, as_trade_bider_id = ur_user.id, as_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.as_trade_side.add(ur_user, sell_bill.as_seller)
											sell_bill.delete()
									if rest_buy_amount > 0:
										this_buy_order = as_buy_pending(as_buyer = ur_user, as_buy_price = ord_price, as_buy_amount = rest_buy_amount, as_buy_maker_id = ur_user.id)
										this_buy_order.save()
								buy_pending = ur_user.as_buy_pending_set.all()
						
						# add record
						new_record = as_history(as_actor = ur_user.id, as_action = ord_direction, as_price = ord_price, as_amount = ord_amount)
						new_record.save()
						# refresh orderbook, maybe need a try: pass
						if (ord_direction == '1' and ord_price < orderbook_list[0].as_orderbook_price) or (ord_direction == '2' and ord_price > orderbook_list[19].as_orderbook_price):
							sell_orderbook = as_sell_pending.objects.all().order_by('as_sell_price')[:10]#low to high
							buy_orderbook = as_buy_pending.objects.all().order_by('-as_buy_price')[:10]#high to low
							num_sell = sell_orderbook.count()
							num_buy = buy_orderbook.count()
							for i in range(num_sell):
								tmp_orderbook_record = as_orderbook.objects.get(pk = 10 - i)
								tmp_orderbook_record.as_orderbook_price = sell_orderbook[i].as_sell_price
								tmp_orderbook_record.as_orderbook_amount = sell_orderbook[i].as_sell_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_sell):
								tmp_orderbook_record = as_orderbook.objects.get(pk = 10 - num_sell - i)
								tmp_orderbook_record.as_orderbook_price = 0.01
								tmp_orderbook_record.as_orderbook_amount = 0
								tmp_orderbook_record.save()
							for i in range(num_buy):
								tmp_orderbook_record = as_orderbook.objects.get(pk = 11 + i)
								tmp_orderbook_record.as_orderbook_price = buy_orderbook[i].as_buy_price
								tmp_orderbook_record.as_orderbook_amount = buy_orderbook[i].as_buy_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_buy):
								tmp_orderbook_record = as_orderbook.objects.get(pk = 11 + num_buy + i)
								tmp_orderbook_record.as_orderbook_price = 0.0
								tmp_orderbook_record.as_orderbook_amount = 0
								tmp_orderbook_record.save()
							orderbook_list = as_orderbook.objects.all().order_by('id')
						
						info = "ORDER SUCCESSFULLY SUBMITTED"
						return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
						
				else:
					return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			set_form = order_form()
			return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def au_process_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = au_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.au_sell_pending_set.all()
			buy_pending = ur_user.au_buy_pending_set.all()
			del_form = cancel_form()
			if request.method == 'POST':
				#check google recaptcha later
				set_form = order_form(request.POST)
				if set_form.is_valid():
					ord_amount = set_form.cleaned_data['orderamountfld']
					ord_price = set_form.cleaned_data['orderpricefld']
					ord_direction = set_form.cleaned_data['orderdirection']
					user_token = set_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						info = "INCORRECT TRADE PIN"
						return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
					if ur_user.password_trade == signed_pin:
						#sell
						if ord_direction == '1':
							#need transaction later
							if ord_amount > ur_user.asset_free * 100:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_amount <= ur_user.asset_free * 100:
								ur_user.asset_free = ur_user.asset_free - ord_amount / 100
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_amount / 100
								ur_user.save()
								sell_qualify_list = au_buy_pending.objects.all().filter(au_buy_price__gte = ord_price).order_by('-au_buy_price')#high to low
								if sell_qualify_list.count() == 0:
									this_sell_order = au_sell_pending(au_seller = ur_user, au_sell_price = ord_price, au_sell_amount = ord_amount, au_sell_maker_id = ur_user.id)
									this_sell_order.save()
								if sell_qualify_list.count() > 0:
									rest_sell_amount = ord_amount
									for buy_bill in sell_qualify_list:
										if buy_bill.au_buy_amount > rest_sell_amount:
											buy_bill.au_buy_amount = buy_bill.au_buy_amount - rest_sell_amount
											buy_bill.save()
											new_position = au_trade_deal(au_trade_price = ord_price, au_trade_amount = rest_sell_amount, au_trade_asker_id = ur_user.id, au_trade_asker_name = ur_user.client_name, au_trade_bider_id = buy_bill.au_buyer.id, au_trade_bider_name = buy_bill.au_buyer.client_name)
											new_position.save()
											new_position.au_trade_side.add(buy_bill.au_buyer, ur_user)
											rest_sell_amount = 0
											break
										if buy_bill.au_buy_amount == rest_sell_amount:
											new_position = au_trade_deal(au_trade_price = ord_price, au_trade_amount = rest_sell_amount, au_trade_asker_id = ur_user.id, au_trade_asker_name = ur_user.client_name, au_trade_bider_id = buy_bill.au_buyer.id, au_trade_bider_name = buy_bill.au_buyer.client_name)
											new_position.save()
											new_position.au_trade_side.add(buy_bill.au_buyer, ur_user)
											buy_bill.delete()
											rest_sell_amount = 0
											break
										if buy_bill.au_buy_amount < rest_sell_amount:
											rest_sell_amount = rest_sell_amount - buy_bill.au_buy_amount
											new_position = au_trade_deal(au_trade_price = ord_price, au_trade_amount = buy_bill.au_buy_amount, au_trade_asker_id = ur_user.id, au_trade_asker_name = ur_user.client_name, au_trade_bider_id = buy_bill.au_buyer.id, au_trade_bider_name = buy_bill.au_buyer.client_name)
											new_position.save()
											new_position.au_trade_side.add(buy_bill.au_buyer, ur_user)
											buy_bill.delete()
									if rest_sell_amount > 0:
										this_sell_order = au_sell_pending(au_seller = ur_user, au_sell_price = ord_price, au_sell_amount = rest_sell_amount, au_sell_maker_id = ur_user.id)
										this_sell_order.save()
								sell_pending = ur_user.au_sell_pending_set.all()
						
						#buy
						if ord_direction == '2':
							#need transaction later
							if ord_price * ord_amount > ur_user.asset_free:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_price * ord_amount <= ur_user.asset_free:
								ur_user.asset_free = ur_user.asset_free - ord_price * ord_amount
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_price * ord_amount
								ur_user.save()
								buy_qualify_list = au_sell_pending.objects.all().filter(au_sell_price__lte = ord_price).order_by('au_sell_price')#low to high
								if buy_qualify_list.count() == 0:
									this_buy_order = au_buy_pending(au_buyer = ur_user, au_buy_price = ord_price, au_buy_amount = ord_amount, au_buy_maker_id = ur_user.id)
									this_buy_order.save()
								if buy_qualify_list.count() > 0:
									rest_buy_amount = ord_amount
									for sell_bill in buy_qualify_list:
										if sell_bill.au_sell_amount > rest_buy_amount:
											sell_bill.au_sell_amount = sell_bill.au_sell_amount - rest_buy_amount
											sell_bill.save()
											new_position = au_trade_deal(au_trade_price = ord_price, au_trade_amount = rest_buy_amount, au_trade_asker_id = sell_bill.au_seller.id, au_trade_asker_name = sell_bill.au_seller.client_name, au_trade_bider_id = ur_user.id, au_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.au_trade_side.add(ur_user, sell_bill.au_seller)
											rest_buy_amount = 0
											break
										if sell_bill.au_sell_amount == rest_buy_amount:
											new_position = au_trade_deal(au_trade_price = ord_price, au_trade_amount = rest_buy_amount, au_trade_asker_id = sell_bill.au_seller.id, au_trade_asker_name = sell_bill.au_seller.client_name, au_trade_bider_id = ur_user.id, au_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.au_trade_side.add(ur_user, sell_bill.au_seller)
											sell_bill.delete()
											rest_buy_amount = 0
											break
										if sell_bill.au_sell_amount < rest_buy_amount:
											rest_buy_amount = rest_buy_amount - sell_bill.au_sell_amount
											new_position = au_trade_deal(au_trade_price = ord_price, au_trade_amount = sell_bill.au_sell_amount, au_trade_asker_id = sell_bill.au_seller.id, au_trade_asker_name = sell_bill.au_seller.client_name, au_trade_bider_id = ur_user.id, au_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.au_trade_side.add(ur_user, sell_bill.au_seller)
											sell_bill.delete()
									if rest_buy_amount > 0:
										this_buy_order = au_buy_pending(au_buyer = ur_user, au_buy_price = ord_price, au_buy_amount = rest_buy_amount, au_buy_maker_id = ur_user.id)
										this_buy_order.save()
								buy_pending = ur_user.au_buy_pending_set.all()
						
						# add record
						new_record = au_history(au_actor = ur_user.id, au_action = ord_direction, au_price = ord_price, au_amount = ord_amount)
						new_record.save()
						# refresh orderbook, maybe need a try: pass
						if (ord_direction == '1' and ord_price < orderbook_list[0].au_orderbook_price) or (ord_direction == '2' and ord_price > orderbook_list[19].au_orderbook_price):
							sell_orderbook = au_sell_pending.objects.all().order_by('au_sell_price')[:10]#low to high
							buy_orderbook = au_buy_pending.objects.all().order_by('-au_buy_price')[:10]#high to low
							num_sell = sell_orderbook.count()
							num_buy = buy_orderbook.count()
							for i in range(num_sell):
								tmp_orderbook_record = au_orderbook.objects.get(pk = 10 - i)
								tmp_orderbook_record.au_orderbook_price = sell_orderbook[i].au_sell_price
								tmp_orderbook_record.au_orderbook_amount = sell_orderbook[i].au_sell_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_sell):
								tmp_orderbook_record = au_orderbook.objects.get(pk = 10 - num_sell - i)
								tmp_orderbook_record.au_orderbook_price = 0.01
								tmp_orderbook_record.au_orderbook_amount = 0
								tmp_orderbook_record.save()
							for i in range(num_buy):
								tmp_orderbook_record = au_orderbook.objects.get(pk = 11 + i)
								tmp_orderbook_record.au_orderbook_price = buy_orderbook[i].au_buy_price
								tmp_orderbook_record.au_orderbook_amount = buy_orderbook[i].au_buy_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_buy):
								tmp_orderbook_record = au_orderbook.objects.get(pk = 11 + num_buy + i)
								tmp_orderbook_record.au_orderbook_price = 0.0
								tmp_orderbook_record.au_orderbook_amount = 0
								tmp_orderbook_record.save()
							orderbook_list = au_orderbook.objects.all().order_by('id')
						
						info = "ORDER SUCCESSFULLY SUBMITTED"
						return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
						
				else:
					return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			set_form = order_form()
			return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def bk_process_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = bk_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.bk_sell_pending_set.all()
			buy_pending = ur_user.bk_buy_pending_set.all()
			del_form = cancel_form()
			if request.method == 'POST':
				#check google recaptcha later
				set_form = order_form(request.POST)
				if set_form.is_valid():
					ord_amount = set_form.cleaned_data['orderamountfld']
					ord_price = set_form.cleaned_data['orderpricefld']
					ord_direction = set_form.cleaned_data['orderdirection']
					user_token = set_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						info = "INCORRECT TRADE PIN"
						return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
					if ur_user.password_trade == signed_pin:
						#sell
						if ord_direction == '1':
							#need transaction later
							if ord_amount > ur_user.asset_free * 100:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_amount <= ur_user.asset_free * 100:
								ur_user.asset_free = ur_user.asset_free - ord_amount / 100
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_amount / 100
								ur_user.save()
								sell_qualify_list = bk_buy_pending.objects.all().filter(bk_buy_price__gte = ord_price).order_by('-bk_buy_price')#high to low
								if sell_qualify_list.count() == 0:
									this_sell_order = bk_sell_pending(bk_seller = ur_user, bk_sell_price = ord_price, bk_sell_amount = ord_amount, bk_sell_maker_id = ur_user.id)
									this_sell_order.save()
								if sell_qualify_list.count() > 0:
									rest_sell_amount = ord_amount
									for buy_bill in sell_qualify_list:
										if buy_bill.bk_buy_amount > rest_sell_amount:
											buy_bill.bk_buy_amount = buy_bill.bk_buy_amount - rest_sell_amount
											buy_bill.save()
											new_position = bk_trade_deal(bk_trade_price = ord_price, bk_trade_amount = rest_sell_amount, bk_trade_asker_id = ur_user.id, bk_trade_asker_name = ur_user.client_name, bk_trade_bider_id = buy_bill.bk_buyer.id, bk_trade_bider_name = buy_bill.bk_buyer.client_name)
											new_position.save()
											new_position.bk_trade_side.add(buy_bill.bk_buyer, ur_user)
											rest_sell_amount = 0
											break
										if buy_bill.bk_buy_amount == rest_sell_amount:
											new_position = bk_trade_deal(bk_trade_price = ord_price, bk_trade_amount = rest_sell_amount, bk_trade_asker_id = ur_user.id, bk_trade_asker_name = ur_user.client_name, bk_trade_bider_id = buy_bill.bk_buyer.id, bk_trade_bider_name = buy_bill.bk_buyer.client_name)
											new_position.save()
											new_position.bk_trade_side.add(buy_bill.bk_buyer, ur_user)
											buy_bill.delete()
											rest_sell_amount = 0
											break
										if buy_bill.bk_buy_amount < rest_sell_amount:
											rest_sell_amount = rest_sell_amount - buy_bill.bk_buy_amount
											new_position = bk_trade_deal(bk_trade_price = ord_price, bk_trade_amount = buy_bill.bk_buy_amount, bk_trade_asker_id = ur_user.id, bk_trade_asker_name = ur_user.client_name, bk_trade_bider_id = buy_bill.bk_buyer.id, bk_trade_bider_name = buy_bill.bk_buyer.client_name)
											new_position.save()
											new_position.bk_trade_side.add(buy_bill.bk_buyer, ur_user)
											buy_bill.delete()
									if rest_sell_amount > 0:
										this_sell_order = bk_sell_pending(bk_seller = ur_user, bk_sell_price = ord_price, bk_sell_amount = rest_sell_amount, bk_sell_maker_id = ur_user.id)
										this_sell_order.save()
								sell_pending = ur_user.bk_sell_pending_set.all()
						
						#buy
						if ord_direction == '2':
							#need transaction later
							if ord_price * ord_amount > ur_user.asset_free:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_price * ord_amount <= ur_user.asset_free:
								ur_user.asset_free = ur_user.asset_free - ord_price * ord_amount
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_price * ord_amount
								ur_user.save()
								buy_qualify_list = bk_sell_pending.objects.all().filter(bk_sell_price__lte = ord_price).order_by('bk_sell_price')#low to high
								if buy_qualify_list.count() == 0:
									this_buy_order = bk_buy_pending(bk_buyer = ur_user, bk_buy_price = ord_price, bk_buy_amount = ord_amount, bk_buy_maker_id = ur_user.id)
									this_buy_order.save()
								if buy_qualify_list.count() > 0:
									rest_buy_amount = ord_amount
									for sell_bill in buy_qualify_list:
										if sell_bill.bk_sell_amount > rest_buy_amount:
											sell_bill.bk_sell_amount = sell_bill.bk_sell_amount - rest_buy_amount
											sell_bill.save()
											new_position = bk_trade_deal(bk_trade_price = ord_price, bk_trade_amount = rest_buy_amount, bk_trade_asker_id = sell_bill.bk_seller.id, bk_trade_asker_name = sell_bill.bk_seller.client_name, bk_trade_bider_id = ur_user.id, bk_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.bk_trade_side.add(ur_user, sell_bill.bk_seller)
											rest_buy_amount = 0
											break
										if sell_bill.bk_sell_amount == rest_buy_amount:
											new_position = bk_trade_deal(bk_trade_price = ord_price, bk_trade_amount = rest_buy_amount, bk_trade_asker_id = sell_bill.bk_seller.id, bk_trade_asker_name = sell_bill.bk_seller.client_name, bk_trade_bider_id = ur_user.id, bk_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.bk_trade_side.add(ur_user, sell_bill.bk_seller)
											sell_bill.delete()
											rest_buy_amount = 0
											break
										if sell_bill.bk_sell_amount < rest_buy_amount:
											rest_buy_amount = rest_buy_amount - sell_bill.bk_sell_amount
											new_position = bk_trade_deal(bk_trade_price = ord_price, bk_trade_amount = sell_bill.bk_sell_amount, bk_trade_asker_id = sell_bill.bk_seller.id, bk_trade_asker_name = sell_bill.bk_seller.client_name, bk_trade_bider_id = ur_user.id, bk_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.bk_trade_side.add(ur_user, sell_bill.bk_seller)
											sell_bill.delete()
									if rest_buy_amount > 0:
										this_buy_order = bk_buy_pending(bk_buyer = ur_user, bk_buy_price = ord_price, bk_buy_amount = rest_buy_amount, bk_buy_maker_id = ur_user.id)
										this_buy_order.save()
								buy_pending = ur_user.bk_buy_pending_set.all()
						
						# add record
						new_record = bk_history(bk_actor = ur_user.id, bk_action = ord_direction, bk_price = ord_price, bk_amount = ord_amount)
						new_record.save()
						# refresh orderbook, maybe need a try: pass
						if (ord_direction == '1' and ord_price < orderbook_list[0].bk_orderbook_price) or (ord_direction == '2' and ord_price > orderbook_list[19].bk_orderbook_price):
							sell_orderbook = bk_sell_pending.objects.all().order_by('bk_sell_price')[:10]#low to high
							buy_orderbook = bk_buy_pending.objects.all().order_by('-bk_buy_price')[:10]#high to low
							num_sell = sell_orderbook.count()
							num_buy = buy_orderbook.count()
							for i in range(num_sell):
								tmp_orderbook_record = bk_orderbook.objects.get(pk = 10 - i)
								tmp_orderbook_record.bk_orderbook_price = sell_orderbook[i].bk_sell_price
								tmp_orderbook_record.bk_orderbook_amount = sell_orderbook[i].bk_sell_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_sell):
								tmp_orderbook_record = bk_orderbook.objects.get(pk = 10 - num_sell - i)
								tmp_orderbook_record.bk_orderbook_price = 0.01
								tmp_orderbook_record.bk_orderbook_amount = 0
								tmp_orderbook_record.save()
							for i in range(num_buy):
								tmp_orderbook_record = bk_orderbook.objects.get(pk = 11 + i)
								tmp_orderbook_record.bk_orderbook_price = buy_orderbook[i].bk_buy_price
								tmp_orderbook_record.bk_orderbook_amount = buy_orderbook[i].bk_buy_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_buy):
								tmp_orderbook_record = bk_orderbook.objects.get(pk = 11 + num_buy + i)
								tmp_orderbook_record.bk_orderbook_price = 0.0
								tmp_orderbook_record.bk_orderbook_amount = 0
								tmp_orderbook_record.save()
							orderbook_list = bk_orderbook.objects.all().order_by('id')
						
						info = "ORDER SUCCESSFULLY SUBMITTED"
						return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
						
				else:
					return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			set_form = order_form()
			return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def ba_process_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = ba_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.ba_sell_pending_set.all()
			buy_pending = ur_user.ba_buy_pending_set.all()
			del_form = cancel_form()
			if request.method == 'POST':
				#check google recaptcha later
				set_form = order_form(request.POST)
				if set_form.is_valid():
					ord_amount = set_form.cleaned_data['orderamountfld']
					ord_price = set_form.cleaned_data['orderpricefld']
					ord_direction = set_form.cleaned_data['orderdirection']
					user_token = set_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						info = "INCORRECT TRADE PIN"
						return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
					if ur_user.password_trade == signed_pin:
						#sell
						if ord_direction == '1':
							#need transaction later
							if ord_amount > ur_user.asset_free * 100:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_amount <= ur_user.asset_free * 100:
								ur_user.asset_free = ur_user.asset_free - ord_amount / 100
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_amount / 100
								ur_user.save()
								sell_qualify_list = ba_buy_pending.objects.all().filter(ba_buy_price__gte = ord_price).order_by('-ba_buy_price')#high to low
								if sell_qualify_list.count() == 0:
									this_sell_order = ba_sell_pending(ba_seller = ur_user, ba_sell_price = ord_price, ba_sell_amount = ord_amount, ba_sell_maker_id = ur_user.id)
									this_sell_order.save()
								if sell_qualify_list.count() > 0:
									rest_sell_amount = ord_amount
									for buy_bill in sell_qualify_list:
										if buy_bill.ba_buy_amount > rest_sell_amount:
											buy_bill.ba_buy_amount = buy_bill.ba_buy_amount - rest_sell_amount
											buy_bill.save()
											new_position = ba_trade_deal(ba_trade_price = ord_price, ba_trade_amount = rest_sell_amount, ba_trade_asker_id = ur_user.id, ba_trade_asker_name = ur_user.client_name, ba_trade_bider_id = buy_bill.ba_buyer.id, ba_trade_bider_name = buy_bill.ba_buyer.client_name)
											new_position.save()
											new_position.ba_trade_side.add(buy_bill.ba_buyer, ur_user)
											rest_sell_amount = 0
											break
										if buy_bill.ba_buy_amount == rest_sell_amount:
											new_position = ba_trade_deal(ba_trade_price = ord_price, ba_trade_amount = rest_sell_amount, ba_trade_asker_id = ur_user.id, ba_trade_asker_name = ur_user.client_name, ba_trade_bider_id = buy_bill.ba_buyer.id, ba_trade_bider_name = buy_bill.ba_buyer.client_name)
											new_position.save()
											new_position.ba_trade_side.add(buy_bill.ba_buyer, ur_user)
											buy_bill.delete()
											rest_sell_amount = 0
											break
										if buy_bill.ba_buy_amount < rest_sell_amount:
											rest_sell_amount = rest_sell_amount - buy_bill.ba_buy_amount
											new_position = ba_trade_deal(ba_trade_price = ord_price, ba_trade_amount = buy_bill.ba_buy_amount, ba_trade_asker_id = ur_user.id, ba_trade_asker_name = ur_user.client_name, ba_trade_bider_id = buy_bill.ba_buyer.id, ba_trade_bider_name = buy_bill.ba_buyer.client_name)
											new_position.save()
											new_position.ba_trade_side.add(buy_bill.ba_buyer, ur_user)
											buy_bill.delete()
									if rest_sell_amount > 0:
										this_sell_order = ba_sell_pending(ba_seller = ur_user, ba_sell_price = ord_price, ba_sell_amount = rest_sell_amount, ba_sell_maker_id = ur_user.id)
										this_sell_order.save()
								sell_pending = ur_user.ba_sell_pending_set.all()
						
						#buy
						if ord_direction == '2':
							#need transaction later
							if ord_price * ord_amount > ur_user.asset_free:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_price * ord_amount <= ur_user.asset_free:
								ur_user.asset_free = ur_user.asset_free - ord_price * ord_amount
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_price * ord_amount
								ur_user.save()
								buy_qualify_list = ba_sell_pending.objects.all().filter(ba_sell_price__lte = ord_price).order_by('ba_sell_price')#low to high
								if buy_qualify_list.count() == 0:
									this_buy_order = ba_buy_pending(ba_buyer = ur_user, ba_buy_price = ord_price, ba_buy_amount = ord_amount, ba_buy_maker_id = ur_user.id)
									this_buy_order.save()
								if buy_qualify_list.count() > 0:
									rest_buy_amount = ord_amount
									for sell_bill in buy_qualify_list:
										if sell_bill.ba_sell_amount > rest_buy_amount:
											sell_bill.ba_sell_amount = sell_bill.ba_sell_amount - rest_buy_amount
											sell_bill.save()
											new_position = ba_trade_deal(ba_trade_price = ord_price, ba_trade_amount = rest_buy_amount, ba_trade_asker_id = sell_bill.ba_seller.id, ba_trade_asker_name = sell_bill.ba_seller.client_name, ba_trade_bider_id = ur_user.id, ba_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.ba_trade_side.add(ur_user, sell_bill.ba_seller)
											rest_buy_amount = 0
											break
										if sell_bill.ba_sell_amount == rest_buy_amount:
											new_position = ba_trade_deal(ba_trade_price = ord_price, ba_trade_amount = rest_buy_amount, ba_trade_asker_id = sell_bill.ba_seller.id, ba_trade_asker_name = sell_bill.ba_seller.client_name, ba_trade_bider_id = ur_user.id, ba_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.ba_trade_side.add(ur_user, sell_bill.ba_seller)
											sell_bill.delete()
											rest_buy_amount = 0
											break
										if sell_bill.ba_sell_amount < rest_buy_amount:
											rest_buy_amount = rest_buy_amount - sell_bill.ba_sell_amount
											new_position = ba_trade_deal(ba_trade_price = ord_price, ba_trade_amount = sell_bill.ba_sell_amount, ba_trade_asker_id = sell_bill.ba_seller.id, ba_trade_asker_name = sell_bill.ba_seller.client_name, ba_trade_bider_id = ur_user.id, ba_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.ba_trade_side.add(ur_user, sell_bill.ba_seller)
											sell_bill.delete()
									if rest_buy_amount > 0:
										this_buy_order = ba_buy_pending(ba_buyer = ur_user, ba_buy_price = ord_price, ba_buy_amount = rest_buy_amount, ba_buy_maker_id = ur_user.id)
										this_buy_order.save()
								buy_pending = ur_user.ba_buy_pending_set.all()
						
						# add record
						new_record = ba_history(ba_actor = ur_user.id, ba_action = ord_direction, ba_price = ord_price, ba_amount = ord_amount)
						new_record.save()
						# refresh orderbook, maybe need a try: pass
						if (ord_direction == '1' and ord_price < orderbook_list[0].ba_orderbook_price) or (ord_direction == '2' and ord_price > orderbook_list[19].ba_orderbook_price):
							sell_orderbook = ba_sell_pending.objects.all().order_by('ba_sell_price')[:10]#low to high
							buy_orderbook = ba_buy_pending.objects.all().order_by('-ba_buy_price')[:10]#high to low
							num_sell = sell_orderbook.count()
							num_buy = buy_orderbook.count()
							for i in range(num_sell):
								tmp_orderbook_record = ba_orderbook.objects.get(pk = 10 - i)
								tmp_orderbook_record.ba_orderbook_price = sell_orderbook[i].ba_sell_price
								tmp_orderbook_record.ba_orderbook_amount = sell_orderbook[i].ba_sell_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_sell):
								tmp_orderbook_record = ba_orderbook.objects.get(pk = 10 - num_sell - i)
								tmp_orderbook_record.ba_orderbook_price = 0.01
								tmp_orderbook_record.ba_orderbook_amount = 0
								tmp_orderbook_record.save()
							for i in range(num_buy):
								tmp_orderbook_record = ba_orderbook.objects.get(pk = 11 + i)
								tmp_orderbook_record.ba_orderbook_price = buy_orderbook[i].ba_buy_price
								tmp_orderbook_record.ba_orderbook_amount = buy_orderbook[i].ba_buy_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_buy):
								tmp_orderbook_record = ba_orderbook.objects.get(pk = 11 + num_buy + i)
								tmp_orderbook_record.ba_orderbook_price = 0.0
								tmp_orderbook_record.ba_orderbook_amount = 0
								tmp_orderbook_record.save()
							orderbook_list = ba_orderbook.objects.all().order_by('id')
						
						info = "ORDER SUCCESSFULLY SUBMITTED"
						return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
						
				else:
					return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			set_form = order_form()
			return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def bs_process_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = bs_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.bs_sell_pending_set.all()
			buy_pending = ur_user.bs_buy_pending_set.all()
			del_form = cancel_form()
			if request.method == 'POST':
				#check google recaptcha later
				set_form = order_form(request.POST)
				if set_form.is_valid():
					ord_amount = set_form.cleaned_data['orderamountfld']
					ord_price = set_form.cleaned_data['orderpricefld']
					ord_direction = set_form.cleaned_data['orderdirection']
					user_token = set_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						info = "INCORRECT TRADE PIN"
						return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
					if ur_user.password_trade == signed_pin:
						#sell
						if ord_direction == '1':
							#need transaction later
							if ord_amount > ur_user.asset_free * 100:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_amount <= ur_user.asset_free * 100:
								ur_user.asset_free = ur_user.asset_free - ord_amount / 100
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_amount / 100
								ur_user.save()
								sell_qualify_list = bs_buy_pending.objects.all().filter(bs_buy_price__gte = ord_price).order_by('-bs_buy_price')#high to low
								if sell_qualify_list.count() == 0:
									this_sell_order = bs_sell_pending(bs_seller = ur_user, bs_sell_price = ord_price, bs_sell_amount = ord_amount, bs_sell_maker_id = ur_user.id)
									this_sell_order.save()
								if sell_qualify_list.count() > 0:
									rest_sell_amount = ord_amount
									for buy_bill in sell_qualify_list:
										if buy_bill.bs_buy_amount > rest_sell_amount:
											buy_bill.bs_buy_amount = buy_bill.bs_buy_amount - rest_sell_amount
											buy_bill.save()
											new_position = bs_trade_deal(bs_trade_price = ord_price, bs_trade_amount = rest_sell_amount, bs_trade_asker_id = ur_user.id, bs_trade_asker_name = ur_user.client_name, bs_trade_bider_id = buy_bill.bs_buyer.id, bs_trade_bider_name = buy_bill.bs_buyer.client_name)
											new_position.save()
											new_position.bs_trade_side.add(buy_bill.bs_buyer, ur_user)
											rest_sell_amount = 0
											break
										if buy_bill.bs_buy_amount == rest_sell_amount:
											new_position = bs_trade_deal(bs_trade_price = ord_price, bs_trade_amount = rest_sell_amount, bs_trade_asker_id = ur_user.id, bs_trade_asker_name = ur_user.client_name, bs_trade_bider_id = buy_bill.bs_buyer.id, bs_trade_bider_name = buy_bill.bs_buyer.client_name)
											new_position.save()
											new_position.bs_trade_side.add(buy_bill.bs_buyer, ur_user)
											buy_bill.delete()
											rest_sell_amount = 0
											break
										if buy_bill.bs_buy_amount < rest_sell_amount:
											rest_sell_amount = rest_sell_amount - buy_bill.bs_buy_amount
											new_position = bs_trade_deal(bs_trade_price = ord_price, bs_trade_amount = buy_bill.bs_buy_amount, bs_trade_asker_id = ur_user.id, bs_trade_asker_name = ur_user.client_name, bs_trade_bider_id = buy_bill.bs_buyer.id, bs_trade_bider_name = buy_bill.bs_buyer.client_name)
											new_position.save()
											new_position.bs_trade_side.add(buy_bill.bs_buyer, ur_user)
											buy_bill.delete()
									if rest_sell_amount > 0:
										this_sell_order = bs_sell_pending(bs_seller = ur_user, bs_sell_price = ord_price, bs_sell_amount = rest_sell_amount, bs_sell_maker_id = ur_user.id)
										this_sell_order.save()
								sell_pending = ur_user.bs_sell_pending_set.all()
						
						#buy
						if ord_direction == '2':
							#need transaction later
							if ord_price * ord_amount > ur_user.asset_free:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_price * ord_amount <= ur_user.asset_free:
								ur_user.asset_free = ur_user.asset_free - ord_price * ord_amount
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_price * ord_amount
								ur_user.save()
								buy_qualify_list = bs_sell_pending.objects.all().filter(bs_sell_price__lte = ord_price).order_by('bs_sell_price')#low to high
								if buy_qualify_list.count() == 0:
									this_buy_order = bs_buy_pending(bs_buyer = ur_user, bs_buy_price = ord_price, bs_buy_amount = ord_amount, bs_buy_maker_id = ur_user.id)
									this_buy_order.save()
								if buy_qualify_list.count() > 0:
									rest_buy_amount = ord_amount
									for sell_bill in buy_qualify_list:
										if sell_bill.bs_sell_amount > rest_buy_amount:
											sell_bill.bs_sell_amount = sell_bill.bs_sell_amount - rest_buy_amount
											sell_bill.save()
											new_position = bs_trade_deal(bs_trade_price = ord_price, bs_trade_amount = rest_buy_amount, bs_trade_asker_id = sell_bill.bs_seller.id, bs_trade_asker_name = sell_bill.bs_seller.client_name, bs_trade_bider_id = ur_user.id, bs_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.bs_trade_side.add(ur_user, sell_bill.bs_seller)
											rest_buy_amount = 0
											break
										if sell_bill.bs_sell_amount == rest_buy_amount:
											new_position = bs_trade_deal(bs_trade_price = ord_price, bs_trade_amount = rest_buy_amount, bs_trade_asker_id = sell_bill.bs_seller.id, bs_trade_asker_name = sell_bill.bs_seller.client_name, bs_trade_bider_id = ur_user.id, bs_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.bs_trade_side.add(ur_user, sell_bill.bs_seller)
											sell_bill.delete()
											rest_buy_amount = 0
											break
										if sell_bill.bs_sell_amount < rest_buy_amount:
											rest_buy_amount = rest_buy_amount - sell_bill.bs_sell_amount
											new_position = bs_trade_deal(bs_trade_price = ord_price, bs_trade_amount = sell_bill.bs_sell_amount, bs_trade_asker_id = sell_bill.bs_seller.id, bs_trade_asker_name = sell_bill.bs_seller.client_name, bs_trade_bider_id = ur_user.id, bs_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.bs_trade_side.add(ur_user, sell_bill.bs_seller)
											sell_bill.delete()
									if rest_buy_amount > 0:
										this_buy_order = bs_buy_pending(bs_buyer = ur_user, bs_buy_price = ord_price, bs_buy_amount = rest_buy_amount, bs_buy_maker_id = ur_user.id)
										this_buy_order.save()
								buy_pending = ur_user.bs_buy_pending_set.all()
						
						# add record
						new_record = bs_history(bs_actor = ur_user.id, bs_action = ord_direction, bs_price = ord_price, bs_amount = ord_amount)
						new_record.save()
						# refresh orderbook, maybe need a try: pass
						if (ord_direction == '1' and ord_price < orderbook_list[0].bs_orderbook_price) or (ord_direction == '2' and ord_price > orderbook_list[19].bs_orderbook_price):
							sell_orderbook = bs_sell_pending.objects.all().order_by('bs_sell_price')[:10]#low to high
							buy_orderbook = bs_buy_pending.objects.all().order_by('-bs_buy_price')[:10]#high to low
							num_sell = sell_orderbook.count()
							num_buy = buy_orderbook.count()
							for i in range(num_sell):
								tmp_orderbook_record = bs_orderbook.objects.get(pk = 10 - i)
								tmp_orderbook_record.bs_orderbook_price = sell_orderbook[i].bs_sell_price
								tmp_orderbook_record.bs_orderbook_amount = sell_orderbook[i].bs_sell_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_sell):
								tmp_orderbook_record = bs_orderbook.objects.get(pk = 10 - num_sell - i)
								tmp_orderbook_record.bs_orderbook_price = 0.01
								tmp_orderbook_record.bs_orderbook_amount = 0
								tmp_orderbook_record.save()
							for i in range(num_buy):
								tmp_orderbook_record = bs_orderbook.objects.get(pk = 11 + i)
								tmp_orderbook_record.bs_orderbook_price = buy_orderbook[i].bs_buy_price
								tmp_orderbook_record.bs_orderbook_amount = buy_orderbook[i].bs_buy_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_buy):
								tmp_orderbook_record = bs_orderbook.objects.get(pk = 11 + num_buy + i)
								tmp_orderbook_record.bs_orderbook_price = 0.0
								tmp_orderbook_record.bs_orderbook_amount = 0
								tmp_orderbook_record.save()
							orderbook_list = bs_orderbook.objects.all().order_by('id')
						
						info = "ORDER SUCCESSFULLY SUBMITTED"
						return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
						
				else:
					return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			set_form = order_form()
			return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def bu_process_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = bu_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.bu_sell_pending_set.all()
			buy_pending = ur_user.bu_buy_pending_set.all()
			del_form = cancel_form()
			if request.method == 'POST':
				#check google recaptcha later
				set_form = order_form(request.POST)
				if set_form.is_valid():
					ord_amount = set_form.cleaned_data['orderamountfld']
					ord_price = set_form.cleaned_data['orderpricefld']
					ord_direction = set_form.cleaned_data['orderdirection']
					user_token = set_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						info = "INCORRECT TRADE PIN"
						return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
					if ur_user.password_trade == signed_pin:
						#sell
						if ord_direction == '1':
							#need transaction later
							if ord_amount > ur_user.asset_free * 100:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_amount <= ur_user.asset_free * 100:
								ur_user.asset_free = ur_user.asset_free - ord_amount / 100
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_amount / 100
								ur_user.save()
								sell_qualify_list = bu_buy_pending.objects.all().filter(bu_buy_price__gte = ord_price).order_by('-bu_buy_price')#high to low
								if sell_qualify_list.count() == 0:
									this_sell_order = bu_sell_pending(bu_seller = ur_user, bu_sell_price = ord_price, bu_sell_amount = ord_amount, bu_sell_maker_id = ur_user.id)
									this_sell_order.save()
								if sell_qualify_list.count() > 0:
									rest_sell_amount = ord_amount
									for buy_bill in sell_qualify_list:
										if buy_bill.bu_buy_amount > rest_sell_amount:
											buy_bill.bu_buy_amount = buy_bill.bu_buy_amount - rest_sell_amount
											buy_bill.save()
											new_position = bu_trade_deal(bu_trade_price = ord_price, bu_trade_amount = rest_sell_amount, bu_trade_asker_id = ur_user.id, bu_trade_asker_name = ur_user.client_name, bu_trade_bider_id = buy_bill.bu_buyer.id, bu_trade_bider_name = buy_bill.bu_buyer.client_name)
											new_position.save()
											new_position.bu_trade_side.add(buy_bill.bu_buyer, ur_user)
											rest_sell_amount = 0
											break
										if buy_bill.bu_buy_amount == rest_sell_amount:
											new_position = bu_trade_deal(bu_trade_price = ord_price, bu_trade_amount = rest_sell_amount, bu_trade_asker_id = ur_user.id, bu_trade_asker_name = ur_user.client_name, bu_trade_bider_id = buy_bill.bu_buyer.id, bu_trade_bider_name = buy_bill.bu_buyer.client_name)
											new_position.save()
											new_position.bu_trade_side.add(buy_bill.bu_buyer, ur_user)
											buy_bill.delete()
											rest_sell_amount = 0
											break
										if buy_bill.bu_buy_amount < rest_sell_amount:
											rest_sell_amount = rest_sell_amount - buy_bill.bu_buy_amount
											new_position = bu_trade_deal(bu_trade_price = ord_price, bu_trade_amount = buy_bill.bu_buy_amount, bu_trade_asker_id = ur_user.id, bu_trade_asker_name = ur_user.client_name, bu_trade_bider_id = buy_bill.bu_buyer.id, bu_trade_bider_name = buy_bill.bu_buyer.client_name)
											new_position.save()
											new_position.bu_trade_side.add(buy_bill.bu_buyer, ur_user)
											buy_bill.delete()
									if rest_sell_amount > 0:
										this_sell_order = bu_sell_pending(bu_seller = ur_user, bu_sell_price = ord_price, bu_sell_amount = rest_sell_amount, bu_sell_maker_id = ur_user.id)
										this_sell_order.save()
								sell_pending = ur_user.bu_sell_pending_set.all()
						
						#buy
						if ord_direction == '2':
							#need transaction later
							if ord_price * ord_amount > ur_user.asset_free:
								info = "YOUR FUND IS INSUFFICIENT FOR THIS ORDER"
								return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
							if ord_price * ord_amount <= ur_user.asset_free:
								ur_user.asset_free = ur_user.asset_free - ord_price * ord_amount
								ur_user.asset_deal_pending = ur_user.asset_deal_pending + ord_price * ord_amount
								ur_user.save()
								buy_qualify_list = bu_sell_pending.objects.all().filter(bu_sell_price__lte = ord_price).order_by('bu_sell_price')#low to high
								if buy_qualify_list.count() == 0:
									this_buy_order = bu_buy_pending(bu_buyer = ur_user, bu_buy_price = ord_price, bu_buy_amount = ord_amount, bu_buy_maker_id = ur_user.id)
									this_buy_order.save()
								if buy_qualify_list.count() > 0:
									rest_buy_amount = ord_amount
									for sell_bill in buy_qualify_list:
										if sell_bill.bu_sell_amount > rest_buy_amount:
											sell_bill.bu_sell_amount = sell_bill.bu_sell_amount - rest_buy_amount
											sell_bill.save()
											new_position = bu_trade_deal(bu_trade_price = ord_price, bu_trade_amount = rest_buy_amount, bu_trade_asker_id = sell_bill.bu_seller.id, bu_trade_asker_name = sell_bill.bu_seller.client_name, bu_trade_bider_id = ur_user.id, bu_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.bu_trade_side.add(ur_user, sell_bill.bu_seller)
											rest_buy_amount = 0
											break
										if sell_bill.bu_sell_amount == rest_buy_amount:
											new_position = bu_trade_deal(bu_trade_price = ord_price, bu_trade_amount = rest_buy_amount, bu_trade_asker_id = sell_bill.bu_seller.id, bu_trade_asker_name = sell_bill.bu_seller.client_name, bu_trade_bider_id = ur_user.id, bu_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.bu_trade_side.add(ur_user, sell_bill.bu_seller)
											sell_bill.delete()
											rest_buy_amount = 0
											break
										if sell_bill.bu_sell_amount < rest_buy_amount:
											rest_buy_amount = rest_buy_amount - sell_bill.bu_sell_amount
											new_position = bu_trade_deal(bu_trade_price = ord_price, bu_trade_amount = sell_bill.bu_sell_amount, bu_trade_asker_id = sell_bill.bu_seller.id, bu_trade_asker_name = sell_bill.bu_seller.client_name, bu_trade_bider_id = ur_user.id, bu_trade_bider_name = ur_user.client_name)
											new_position.save()
											new_position.bu_trade_side.add(ur_user, sell_bill.bu_seller)
											sell_bill.delete()
									if rest_buy_amount > 0:
										this_buy_order = bu_buy_pending(bu_buyer = ur_user, bu_buy_price = ord_price, bu_buy_amount = rest_buy_amount, bu_buy_maker_id = ur_user.id)
										this_buy_order.save()
								buy_pending = ur_user.bu_buy_pending_set.all()
						
						# add record
						new_record = bu_history(bu_actor = ur_user.id, bu_action = ord_direction, bu_price = ord_price, bu_amount = ord_amount)
						new_record.save()
						# refresh orderbook, maybe need a try: pass
						if (ord_direction == '1' and ord_price < orderbook_list[0].bu_orderbook_price) or (ord_direction == '2' and ord_price > orderbook_list[19].bu_orderbook_price):
							sell_orderbook = bu_sell_pending.objects.all().order_by('bu_sell_price')[:10]#low to high
							buy_orderbook = bu_buy_pending.objects.all().order_by('-bu_buy_price')[:10]#high to low
							num_sell = sell_orderbook.count()
							num_buy = buy_orderbook.count()
							for i in range(num_sell):
								tmp_orderbook_record = bu_orderbook.objects.get(pk = 10 - i)
								tmp_orderbook_record.bu_orderbook_price = sell_orderbook[i].bu_sell_price
								tmp_orderbook_record.bu_orderbook_amount = sell_orderbook[i].bu_sell_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_sell):
								tmp_orderbook_record = bu_orderbook.objects.get(pk = 10 - num_sell - i)
								tmp_orderbook_record.bu_orderbook_price = 0.01
								tmp_orderbook_record.bu_orderbook_amount = 0
								tmp_orderbook_record.save()
							for i in range(num_buy):
								tmp_orderbook_record = bu_orderbook.objects.get(pk = 11 + i)
								tmp_orderbook_record.bu_orderbook_price = buy_orderbook[i].bu_buy_price
								tmp_orderbook_record.bu_orderbook_amount = buy_orderbook[i].bu_buy_amount
								tmp_orderbook_record.save()
							for i in range(10 - num_buy):
								tmp_orderbook_record = bu_orderbook.objects.get(pk = 11 + num_buy + i)
								tmp_orderbook_record.bu_orderbook_price = 0.0
								tmp_orderbook_record.bu_orderbook_amount = 0
								tmp_orderbook_record.save()
							orderbook_list = bu_orderbook.objects.all().order_by('id')
						
						info = "ORDER SUCCESSFULLY SUBMITTED"
						return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'info': info})
						
				else:
					return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			set_form = order_form()
			return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
### cancel order
@transaction.atomic
def ak_cancel_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = ak_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.ak_sell_pending_set.all()
			buy_pending = ur_user.ak_buy_pending_set.all()
			set_form = order_form()
			if request.method == 'POST':
				del_form = cancel_form(request.POST)
				if del_form.is_valid():
					del_id = del_form.cleaned_data['targetidfld']
					del_type = del_form.cleaned_data['targettypefld']
					user_token = del_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						infocan = "INCORRECT TRADE PIN"
						return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
					if ur_user.password_trade == signed_pin:
						tmp_price = 0
						tmp_amount = 0
						#del sell
						if del_type == '3':
							#transaction needed
							try:
								sell_to_del = ur_user.ak_sell_pending_set.all().get(pk = del_id)
							except ak_sell_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = sell_to_del.ak_sell_price
								tmp_amount = sell_to_del.ak_sell_amount
								sell_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_amount / 100
								ur_user.asset_free = ur_user.asset_free + tmp_amount / 100
								ur_user.save()
								sell_pending = ur_user.ak_sell_pending_set.all()
								if tmp_price <= orderbook_list[0].ak_orderbook_price:
									sell_orderbook = ak_sell_pending.objects.all().order_by('ak_sell_price')[:10]#low to high
									num_sell = sell_orderbook.count()
									for i in range(num_sell):
										tmp_orderbook_record = ak_orderbook.objects.get(pk = 10 - i)
										tmp_orderbook_record.ak_orderbook_price = sell_orderbook[i].ak_sell_price
										tmp_orderbook_record.ak_orderbook_amount = sell_orderbook[i].ak_sell_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_sell):
										tmp_orderbook_record = ak_orderbook.objects.get(pk = 10 - num_sell - i)
										tmp_orderbook_record.ak_orderbook_price = 0.01
										tmp_orderbook_record.ak_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = ak_orderbook.objects.all().order_by('id')
						#del buy
						if del_type == '4':
							#transaction needed
							try:
								buy_to_del = ur_user.ak_buy_pending_set.all().get(pk = del_id)
							except ak_buy_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = buy_to_del.ak_buy_price
								tmp_amount = buy_to_del.ak_buy_amount
								buy_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_price * tmp_amount
								ur_user.asset_free = ur_user.asset_free + tmp_price * tmp_amount
								ur_user.save()
								buy_pending = ur_user.ak_buy_pending_set.all()
								if tmp_price >= orderbook_list[19].ak_orderbook_price:
									buy_orderbook = ak_buy_pending.objects.all().order_by('-ak_buy_price')[:10]#high to low
									num_buy = buy_orderbook.count()
									for i in range(num_buy):
										tmp_orderbook_record = ak_orderbook.objects.get(pk = 11 + i)
										tmp_orderbook_record.ak_orderbook_price = buy_orderbook[i].ak_buy_price
										tmp_orderbook_record.ak_orderbook_amount = buy_orderbook[i].ak_buy_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_buy):
										tmp_orderbook_record = ak_orderbook.objects.get(pk = 11 + num_buy + i)
										tmp_orderbook_record.ak_orderbook_price = 0.0
										tmp_orderbook_record.ak_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = ak_orderbook.objects.all().order_by('id')
						new_record = ak_history(ak_actor = ur_user.id, ak_action = del_type, ak_price = tmp_price, ak_amount = tmp_amount)
						new_record.save()
						infocan = "CANCEL ORDER OK"
						return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
				else:
					return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			del_form = cancel_form()
			return render(request, 'trade/akorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def aa_cancel_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = aa_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.aa_sell_pending_set.all()
			buy_pending = ur_user.aa_buy_pending_set.all()
			set_form = order_form()
			if request.method == 'POST':
				del_form = cancel_form(request.POST)
				if del_form.is_valid():
					del_id = del_form.cleaned_data['targetidfld']
					del_type = del_form.cleaned_data['targettypefld']
					user_token = del_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						infocan = "INCORRECT TRADE PIN"
						return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
					if ur_user.password_trade == signed_pin:
						tmp_price = 0
						tmp_amount = 0
						#del sell
						if del_type == '3':
							#transaction needed
							try:
								sell_to_del = ur_user.aa_sell_pending_set.all().get(pk = del_id)
							except aa_sell_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = sell_to_del.aa_sell_price
								tmp_amount = sell_to_del.aa_sell_amount
								sell_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_amount / 100
								ur_user.asset_free = ur_user.asset_free + tmp_amount / 100
								ur_user.save()
								sell_pending = ur_user.aa_sell_pending_set.all()
								if tmp_price <= orderbook_list[0].aa_orderbook_price:
									sell_orderbook = aa_sell_pending.objects.all().order_by('aa_sell_price')[:10]#low to high
									num_sell = sell_orderbook.count()
									for i in range(num_sell):
										tmp_orderbook_record = aa_orderbook.objects.get(pk = 10 - i)
										tmp_orderbook_record.aa_orderbook_price = sell_orderbook[i].aa_sell_price
										tmp_orderbook_record.aa_orderbook_amount = sell_orderbook[i].aa_sell_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_sell):
										tmp_orderbook_record = aa_orderbook.objects.get(pk = 10 - num_sell - i)
										tmp_orderbook_record.aa_orderbook_price = 0.01
										tmp_orderbook_record.aa_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = aa_orderbook.objects.all().order_by('id')
						#del buy
						if del_type == '4':
							#transaction needed
							try:
								buy_to_del = ur_user.aa_buy_pending_set.all().get(pk = del_id)
							except aa_buy_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = buy_to_del.aa_buy_price
								tmp_amount = buy_to_del.aa_buy_amount
								buy_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_price * tmp_amount
								ur_user.asset_free = ur_user.asset_free + tmp_price * tmp_amount
								ur_user.save()
								buy_pending = ur_user.aa_buy_pending_set.all()
								if tmp_price >= orderbook_list[19].aa_orderbook_price:
									buy_orderbook = aa_buy_pending.objects.all().order_by('-aa_buy_price')[:10]#high to low
									num_buy = buy_orderbook.count()
									for i in range(num_buy):
										tmp_orderbook_record = aa_orderbook.objects.get(pk = 11 + i)
										tmp_orderbook_record.aa_orderbook_price = buy_orderbook[i].aa_buy_price
										tmp_orderbook_record.aa_orderbook_amount = buy_orderbook[i].aa_buy_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_buy):
										tmp_orderbook_record = aa_orderbook.objects.get(pk = 11 + num_buy + i)
										tmp_orderbook_record.aa_orderbook_price = 0.0
										tmp_orderbook_record.aa_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = aa_orderbook.objects.all().order_by('id')
						new_record = aa_history(aa_actor = ur_user.id, aa_action = del_type, aa_price = tmp_price, aa_amount = tmp_amount)
						new_record.save()
						infocan = "CANCEL ORDER OK"
						return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
				else:
					return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			del_form = cancel_form()
			return render(request, 'trade/aaorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def as_cancel_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = as_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.as_sell_pending_set.all()
			buy_pending = ur_user.as_buy_pending_set.all()
			set_form = order_form()
			if request.method == 'POST':
				del_form = cancel_form(request.POST)
				if del_form.is_valid():
					del_id = del_form.cleaned_data['targetidfld']
					del_type = del_form.cleaned_data['targettypefld']
					user_token = del_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						infocan = "INCORRECT TRADE PIN"
						return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
					if ur_user.password_trade == signed_pin:
						tmp_price = 0
						tmp_amount = 0
						#del sell
						if del_type == '3':
							#transaction needed
							try:
								sell_to_del = ur_user.as_sell_pending_set.all().get(pk = del_id)
							except as_sell_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = sell_to_del.as_sell_price
								tmp_amount = sell_to_del.as_sell_amount
								sell_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_amount / 100
								ur_user.asset_free = ur_user.asset_free + tmp_amount / 100
								ur_user.save()
								sell_pending = ur_user.as_sell_pending_set.all()
								if tmp_price <= orderbook_list[0].as_orderbook_price:
									sell_orderbook = as_sell_pending.objects.all().order_by('as_sell_price')[:10]#low to high
									num_sell = sell_orderbook.count()
									for i in range(num_sell):
										tmp_orderbook_record = as_orderbook.objects.get(pk = 10 - i)
										tmp_orderbook_record.as_orderbook_price = sell_orderbook[i].as_sell_price
										tmp_orderbook_record.as_orderbook_amount = sell_orderbook[i].as_sell_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_sell):
										tmp_orderbook_record = as_orderbook.objects.get(pk = 10 - num_sell - i)
										tmp_orderbook_record.as_orderbook_price = 0.01
										tmp_orderbook_record.as_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = as_orderbook.objects.all().order_by('id')
						#del buy
						if del_type == '4':
							#transaction needed
							try:
								buy_to_del = ur_user.as_buy_pending_set.all().get(pk = del_id)
							except as_buy_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = buy_to_del.as_buy_price
								tmp_amount = buy_to_del.as_buy_amount
								buy_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_price * tmp_amount
								ur_user.asset_free = ur_user.asset_free + tmp_price * tmp_amount
								ur_user.save()
								buy_pending = ur_user.as_buy_pending_set.all()
								if tmp_price >= orderbook_list[19].as_orderbook_price:
									buy_orderbook = as_buy_pending.objects.all().order_by('-as_buy_price')[:10]#high to low
									num_buy = buy_orderbook.count()
									for i in range(num_buy):
										tmp_orderbook_record = as_orderbook.objects.get(pk = 11 + i)
										tmp_orderbook_record.as_orderbook_price = buy_orderbook[i].as_buy_price
										tmp_orderbook_record.as_orderbook_amount = buy_orderbook[i].as_buy_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_buy):
										tmp_orderbook_record = as_orderbook.objects.get(pk = 11 + num_buy + i)
										tmp_orderbook_record.as_orderbook_price = 0.0
										tmp_orderbook_record.as_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = as_orderbook.objects.all().order_by('id')
						new_record = as_history(as_actor = ur_user.id, as_action = del_type, as_price = tmp_price, as_amount = tmp_amount)
						new_record.save()
						infocan = "CANCEL ORDER OK"
						return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
				else:
					return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			del_form = cancel_form()
			return render(request, 'trade/asorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def au_cancel_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = au_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.au_sell_pending_set.all()
			buy_pending = ur_user.au_buy_pending_set.all()
			set_form = order_form()
			if request.method == 'POST':
				del_form = cancel_form(request.POST)
				if del_form.is_valid():
					del_id = del_form.cleaned_data['targetidfld']
					del_type = del_form.cleaned_data['targettypefld']
					user_token = del_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						infocan = "INCORRECT TRADE PIN"
						return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
					if ur_user.password_trade == signed_pin:
						tmp_price = 0
						tmp_amount = 0
						#del sell
						if del_type == '3':
							#transaction needed
							try:
								sell_to_del = ur_user.au_sell_pending_set.all().get(pk = del_id)
							except au_sell_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = sell_to_del.au_sell_price
								tmp_amount = sell_to_del.au_sell_amount
								sell_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_amount / 100
								ur_user.asset_free = ur_user.asset_free + tmp_amount / 100
								ur_user.save()
								sell_pending = ur_user.au_sell_pending_set.all()
								if tmp_price <= orderbook_list[0].au_orderbook_price:
									sell_orderbook = au_sell_pending.objects.all().order_by('au_sell_price')[:10]#low to high
									num_sell = sell_orderbook.count()
									for i in range(num_sell):
										tmp_orderbook_record = au_orderbook.objects.get(pk = 10 - i)
										tmp_orderbook_record.au_orderbook_price = sell_orderbook[i].au_sell_price
										tmp_orderbook_record.au_orderbook_amount = sell_orderbook[i].au_sell_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_sell):
										tmp_orderbook_record = au_orderbook.objects.get(pk = 10 - num_sell - i)
										tmp_orderbook_record.au_orderbook_price = 0.01
										tmp_orderbook_record.au_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = au_orderbook.objects.all().order_by('id')
						#del buy
						if del_type == '4':
							#transaction needed
							try:
								buy_to_del = ur_user.au_buy_pending_set.all().get(pk = del_id)
							except au_buy_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = buy_to_del.au_buy_price
								tmp_amount = buy_to_del.au_buy_amount
								buy_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_price * tmp_amount
								ur_user.asset_free = ur_user.asset_free + tmp_price * tmp_amount
								ur_user.save()
								buy_pending = ur_user.au_buy_pending_set.all()
								if tmp_price >= orderbook_list[19].au_orderbook_price:
									buy_orderbook = au_buy_pending.objects.all().order_by('-au_buy_price')[:10]#high to low
									num_buy = buy_orderbook.count()
									for i in range(num_buy):
										tmp_orderbook_record = au_orderbook.objects.get(pk = 11 + i)
										tmp_orderbook_record.au_orderbook_price = buy_orderbook[i].au_buy_price
										tmp_orderbook_record.au_orderbook_amount = buy_orderbook[i].au_buy_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_buy):
										tmp_orderbook_record = au_orderbook.objects.get(pk = 11 + num_buy + i)
										tmp_orderbook_record.au_orderbook_price = 0.0
										tmp_orderbook_record.au_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = au_orderbook.objects.all().order_by('id')
						new_record = au_history(au_actor = ur_user.id, au_action = del_type, au_price = tmp_price, au_amount = tmp_amount)
						new_record.save()
						infocan = "CANCEL ORDER OK"
						return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
				else:
					return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			del_form = cancel_form()
			return render(request, 'trade/auorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def bk_cancel_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = bk_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.bk_sell_pending_set.all()
			buy_pending = ur_user.bk_buy_pending_set.all()
			set_form = order_form()
			if request.method == 'POST':
				del_form = cancel_form(request.POST)
				if del_form.is_valid():
					del_id = del_form.cleaned_data['targetidfld']
					del_type = del_form.cleaned_data['targettypefld']
					user_token = del_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						infocan = "INCORRECT TRADE PIN"
						return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
					if ur_user.password_trade == signed_pin:
						tmp_price = 0
						tmp_amount = 0
						#del sell
						if del_type == '3':
							#transaction needed
							try:
								sell_to_del = ur_user.bk_sell_pending_set.all().get(pk = del_id)
							except bk_sell_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = sell_to_del.bk_sell_price
								tmp_amount = sell_to_del.bk_sell_amount
								sell_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_amount / 100
								ur_user.asset_free = ur_user.asset_free + tmp_amount / 100
								ur_user.save()
								sell_pending = ur_user.bk_sell_pending_set.all()
								if tmp_price <= orderbook_list[0].bk_orderbook_price:
									sell_orderbook = bk_sell_pending.objects.all().order_by('bk_sell_price')[:10]#low to high
									num_sell = sell_orderbook.count()
									for i in range(num_sell):
										tmp_orderbook_record = bk_orderbook.objects.get(pk = 10 - i)
										tmp_orderbook_record.bk_orderbook_price = sell_orderbook[i].bk_sell_price
										tmp_orderbook_record.bk_orderbook_amount = sell_orderbook[i].bk_sell_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_sell):
										tmp_orderbook_record = bk_orderbook.objects.get(pk = 10 - num_sell - i)
										tmp_orderbook_record.bk_orderbook_price = 0.01
										tmp_orderbook_record.bk_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = bk_orderbook.objects.all().order_by('id')
						#del buy
						if del_type == '4':
							#transaction needed
							try:
								buy_to_del = ur_user.bk_buy_pending_set.all().get(pk = del_id)
							except bk_buy_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = buy_to_del.bk_buy_price
								tmp_amount = buy_to_del.bk_buy_amount
								buy_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_price * tmp_amount
								ur_user.asset_free = ur_user.asset_free + tmp_price * tmp_amount
								ur_user.save()
								buy_pending = ur_user.bk_buy_pending_set.all()
								if tmp_price >= orderbook_list[19].bk_orderbook_price:
									buy_orderbook = bk_buy_pending.objects.all().order_by('-bk_buy_price')[:10]#high to low
									num_buy = buy_orderbook.count()
									for i in range(num_buy):
										tmp_orderbook_record = bk_orderbook.objects.get(pk = 11 + i)
										tmp_orderbook_record.bk_orderbook_price = buy_orderbook[i].bk_buy_price
										tmp_orderbook_record.bk_orderbook_amount = buy_orderbook[i].bk_buy_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_buy):
										tmp_orderbook_record = bk_orderbook.objects.get(pk = 11 + num_buy + i)
										tmp_orderbook_record.bk_orderbook_price = 0.0
										tmp_orderbook_record.bk_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = bk_orderbook.objects.all().order_by('id')
						new_record = bk_history(bk_actor = ur_user.id, bk_action = del_type, bk_price = tmp_price, bk_amount = tmp_amount)
						new_record.save()
						infocan = "CANCEL ORDER OK"
						return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
				else:
					return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			del_form = cancel_form()
			return render(request, 'trade/bkorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def ba_cancel_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = ba_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.ba_sell_pending_set.all()
			buy_pending = ur_user.ba_buy_pending_set.all()
			set_form = order_form()
			if request.method == 'POST':
				del_form = cancel_form(request.POST)
				if del_form.is_valid():
					del_id = del_form.cleaned_data['targetidfld']
					del_type = del_form.cleaned_data['targettypefld']
					user_token = del_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						infocan = "INCORRECT TRADE PIN"
						return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
					if ur_user.password_trade == signed_pin:
						tmp_price = 0
						tmp_amount = 0
						#del sell
						if del_type == '3':
							#transaction needed
							try:
								sell_to_del = ur_user.ba_sell_pending_set.all().get(pk = del_id)
							except ba_sell_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = sell_to_del.ba_sell_price
								tmp_amount = sell_to_del.ba_sell_amount
								sell_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_amount / 100
								ur_user.asset_free = ur_user.asset_free + tmp_amount / 100
								ur_user.save()
								sell_pending = ur_user.ba_sell_pending_set.all()
								if tmp_price <= orderbook_list[0].ba_orderbook_price:
									sell_orderbook = ba_sell_pending.objects.all().order_by('ba_sell_price')[:10]#low to high
									num_sell = sell_orderbook.count()
									for i in range(num_sell):
										tmp_orderbook_record = ba_orderbook.objects.get(pk = 10 - i)
										tmp_orderbook_record.ba_orderbook_price = sell_orderbook[i].ba_sell_price
										tmp_orderbook_record.ba_orderbook_amount = sell_orderbook[i].ba_sell_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_sell):
										tmp_orderbook_record = ba_orderbook.objects.get(pk = 10 - num_sell - i)
										tmp_orderbook_record.ba_orderbook_price = 0.01
										tmp_orderbook_record.ba_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = ba_orderbook.objects.all().order_by('id')
						#del buy
						if del_type == '4':
							#transaction needed
							try:
								buy_to_del = ur_user.ba_buy_pending_set.all().get(pk = del_id)
							except ba_buy_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = buy_to_del.ba_buy_price
								tmp_amount = buy_to_del.ba_buy_amount
								buy_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_price * tmp_amount
								ur_user.asset_free = ur_user.asset_free + tmp_price * tmp_amount
								ur_user.save()
								buy_pending = ur_user.ba_buy_pending_set.all()
								if tmp_price >= orderbook_list[19].ba_orderbook_price:
									buy_orderbook = ba_buy_pending.objects.all().order_by('-ba_buy_price')[:10]#high to low
									num_buy = buy_orderbook.count()
									for i in range(num_buy):
										tmp_orderbook_record = ba_orderbook.objects.get(pk = 11 + i)
										tmp_orderbook_record.ba_orderbook_price = buy_orderbook[i].ba_buy_price
										tmp_orderbook_record.ba_orderbook_amount = buy_orderbook[i].ba_buy_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_buy):
										tmp_orderbook_record = ba_orderbook.objects.get(pk = 11 + num_buy + i)
										tmp_orderbook_record.ba_orderbook_price = 0.0
										tmp_orderbook_record.ba_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = ba_orderbook.objects.all().order_by('id')
						new_record = ba_history(ba_actor = ur_user.id, ba_action = del_type, ba_price = tmp_price, ba_amount = tmp_amount)
						new_record.save()
						infocan = "CANCEL ORDER OK"
						return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
				else:
					return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			del_form = cancel_form()
			return render(request, 'trade/baorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def bs_cancel_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = bs_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.bs_sell_pending_set.all()
			buy_pending = ur_user.bs_buy_pending_set.all()
			set_form = order_form()
			if request.method == 'POST':
				del_form = cancel_form(request.POST)
				if del_form.is_valid():
					del_id = del_form.cleaned_data['targetidfld']
					del_type = del_form.cleaned_data['targettypefld']
					user_token = del_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						infocan = "INCORRECT TRADE PIN"
						return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
					if ur_user.password_trade == signed_pin:
						tmp_price = 0
						tmp_amount = 0
						#del sell
						if del_type == '3':
							#transaction needed
							try:
								sell_to_del = ur_user.bs_sell_pending_set.all().get(pk = del_id)
							except bs_sell_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = sell_to_del.bs_sell_price
								tmp_amount = sell_to_del.bs_sell_amount
								sell_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_amount / 100
								ur_user.asset_free = ur_user.asset_free + tmp_amount / 100
								ur_user.save()
								sell_pending = ur_user.bs_sell_pending_set.all()
								if tmp_price <= orderbook_list[0].bs_orderbook_price:
									sell_orderbook = bs_sell_pending.objects.all().order_by('bs_sell_price')[:10]#low to high
									num_sell = sell_orderbook.count()
									for i in range(num_sell):
										tmp_orderbook_record = bs_orderbook.objects.get(pk = 10 - i)
										tmp_orderbook_record.bs_orderbook_price = sell_orderbook[i].bs_sell_price
										tmp_orderbook_record.bs_orderbook_amount = sell_orderbook[i].bs_sell_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_sell):
										tmp_orderbook_record = bs_orderbook.objects.get(pk = 10 - num_sell - i)
										tmp_orderbook_record.bs_orderbook_price = 0.01
										tmp_orderbook_record.bs_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = bs_orderbook.objects.all().order_by('id')
						#del buy
						if del_type == '4':
							#transaction needed
							try:
								buy_to_del = ur_user.bs_buy_pending_set.all().get(pk = del_id)
							except bs_buy_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = buy_to_del.bs_buy_price
								tmp_amount = buy_to_del.bs_buy_amount
								buy_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_price * tmp_amount
								ur_user.asset_free = ur_user.asset_free + tmp_price * tmp_amount
								ur_user.save()
								buy_pending = ur_user.bs_buy_pending_set.all()
								if tmp_price >= orderbook_list[19].bs_orderbook_price:
									buy_orderbook = bs_buy_pending.objects.all().order_by('-bs_buy_price')[:10]#high to low
									num_buy = buy_orderbook.count()
									for i in range(num_buy):
										tmp_orderbook_record = bs_orderbook.objects.get(pk = 11 + i)
										tmp_orderbook_record.bs_orderbook_price = buy_orderbook[i].bs_buy_price
										tmp_orderbook_record.bs_orderbook_amount = buy_orderbook[i].bs_buy_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_buy):
										tmp_orderbook_record = bs_orderbook.objects.get(pk = 11 + num_buy + i)
										tmp_orderbook_record.bs_orderbook_price = 0.0
										tmp_orderbook_record.bs_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = bs_orderbook.objects.all().order_by('id')
						new_record = bs_history(bs_actor = ur_user.id, bs_action = del_type, bs_price = tmp_price, bs_amount = tmp_amount)
						new_record.save()
						infocan = "CANCEL ORDER OK"
						return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
				else:
					return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			del_form = cancel_form()
			return render(request, 'trade/bsorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))
	
	
@transaction.atomic
def bu_cancel_order(request):
	if 'uid' in request.session:
		try:
			ur_user = client.objects.get(client_name = request.session['uid'])
		except client.DoesNotExist:
			del request.session['uid']
			return HttpResponseRedirect(reverse('trade:index'))
		else:
			orderbook_list = bu_orderbook.objects.all().order_by('id')
			sell_pending = ur_user.bu_sell_pending_set.all()
			buy_pending = ur_user.bu_buy_pending_set.all()
			set_form = order_form()
			if request.method == 'POST':
				del_form = cancel_form(request.POST)
				if del_form.is_valid():
					del_id = del_form.cleaned_data['targetidfld']
					del_type = del_form.cleaned_data['targettypefld']
					user_token = del_form.cleaned_data['tradetokenfld']
					mid_sig_pin = hashlib.md5(user_token.encode("utf8")).hexdigest().upper() + ur_user.email_verify_code
					signed_pin = hashlib.sha256(mid_sig_pin.encode("utf8")).hexdigest()
					if ur_user.password_trade != signed_pin:
						infocan = "INCORRECT TRADE PIN"
						return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
					if ur_user.password_trade == signed_pin:
						tmp_price = 0
						tmp_amount = 0
						#del sell
						if del_type == '3':
							#transaction needed
							try:
								sell_to_del = ur_user.bu_sell_pending_set.all().get(pk = del_id)
							except bu_sell_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = sell_to_del.bu_sell_price
								tmp_amount = sell_to_del.bu_sell_amount
								sell_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_amount / 100
								ur_user.asset_free = ur_user.asset_free + tmp_amount / 100
								ur_user.save()
								sell_pending = ur_user.bu_sell_pending_set.all()
								if tmp_price <= orderbook_list[0].bu_orderbook_price:
									sell_orderbook = bu_sell_pending.objects.all().order_by('bu_sell_price')[:10]#low to high
									num_sell = sell_orderbook.count()
									for i in range(num_sell):
										tmp_orderbook_record = bu_orderbook.objects.get(pk = 10 - i)
										tmp_orderbook_record.bu_orderbook_price = sell_orderbook[i].bu_sell_price
										tmp_orderbook_record.bu_orderbook_amount = sell_orderbook[i].bu_sell_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_sell):
										tmp_orderbook_record = bu_orderbook.objects.get(pk = 10 - num_sell - i)
										tmp_orderbook_record.bu_orderbook_price = 0.01
										tmp_orderbook_record.bu_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = bu_orderbook.objects.all().order_by('id')
						#del buy
						if del_type == '4':
							#transaction needed
							try:
								buy_to_del = ur_user.bu_buy_pending_set.all().get(pk = del_id)
							except bu_buy_pending.DoesNotExist:
								infocan = "NO SUCH ORDER"
								return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
							else:
								tmp_price = buy_to_del.bu_buy_price
								tmp_amount = buy_to_del.bu_buy_amount
								buy_to_del.delete()
								ur_user.asset_deal_pending = ur_user.asset_deal_pending - tmp_price * tmp_amount
								ur_user.asset_free = ur_user.asset_free + tmp_price * tmp_amount
								ur_user.save()
								buy_pending = ur_user.bu_buy_pending_set.all()
								if tmp_price >= orderbook_list[19].bu_orderbook_price:
									buy_orderbook = bu_buy_pending.objects.all().order_by('-bu_buy_price')[:10]#high to low
									num_buy = buy_orderbook.count()
									for i in range(num_buy):
										tmp_orderbook_record = bu_orderbook.objects.get(pk = 11 + i)
										tmp_orderbook_record.bu_orderbook_price = buy_orderbook[i].bu_buy_price
										tmp_orderbook_record.bu_orderbook_amount = buy_orderbook[i].bu_buy_amount
										tmp_orderbook_record.save()
									for i in range(10 - num_buy):
										tmp_orderbook_record = bu_orderbook.objects.get(pk = 11 + num_buy + i)
										tmp_orderbook_record.bu_orderbook_price = 0.0
										tmp_orderbook_record.bu_orderbook_amount = 0
										tmp_orderbook_record.save()
									orderbook_list = bu_orderbook.objects.all().order_by('id')
						new_record = bu_history(bu_actor = ur_user.id, bu_action = del_type, bu_price = tmp_price, bu_amount = tmp_amount)
						new_record.save()
						infocan = "CANCEL ORDER OK"
						return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending, 'infocan': infocan})
				else:
					return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
			del_form = cancel_form()
			return render(request, 'trade/buorder.html', {'orderbook': orderbook_list, 'set_form': set_form, 'del_form': del_form, 'sell_pending': sell_pending, 'buy_pending': buy_pending})
	return HttpResponseRedirect(reverse('trade:index'))