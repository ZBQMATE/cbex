import hashlib
from django import forms
import re

class login_form(forms.Form):
	
	usernamefld = forms.CharField(label = 'Username', max_length = 50)
	passwordfld = forms.CharField(label = 'Password', max_length = 100, widget = forms.PasswordInput)
	
	def clean_usernamefld(self):
		#test whether username is alphanumeric
		usernamefld_a = self.cleaned_data['usernamefld']
		if not re.match("^[A-Za-z0-9_-]*$", usernamefld_a):
			raise forms.ValidationError("NOT A VALID USER NAME")
		if len(usernamefld_a) == 0 or len(usernamefld_a) > 50:
			raise forms.ValidationError("INCORRECT USER NAME")
		return usernamefld_a
	
	def clean_passwordfld(self):
		#test password length
		passwordfld_a = self.cleaned_data['passwordfld']
		if len(passwordfld_a) < 8 or len(passwordfld_a) > 100:
			raise forms.ValidationError("INCORRECT PASSWORD")
		return passwordfld_a
	
	
class signup_form(forms.Form):
	
	verifycodefld = forms.CharField(label = "Email verify code", max_length = 50)
	usernamefld = forms.CharField(label = "Username, numerals and letters only", max_length = 50)
	passwordfld = forms.CharField(label = "Password, at least 8 characters", max_length = 100, widget = forms.PasswordInput)
	passwordconfirmfld = forms.CharField(label = "Confirm your password", max_length = 100, widget = forms.PasswordInput)
	tradetokenfld = forms.CharField(label = "Trade PIN, a password for making orders, at least 6 characters", max_length = 50, widget = forms.PasswordInput)
	tradetokenconfirmfld = forms.CharField(label = "Confirm your trade PIN", max_length = 50, widget = forms.PasswordInput)
	
	def clean_verifycodefld(self):
		verifycodefld_a = self.cleaned_data['verifycodefld']
		if not re.match("^[A-Za-z0-9_-]*$", verifycodefld_a):
			raise forms.ValidationError("NOT A VALID EMAIL CODE")
		if len(verifycodefld_a) == 0 or len(verifycodefld_a) > 50:
			raise forms.ValidationError("INPUT IS NOT ALLOWED")
		return verifycodefld_a
		
	def clean_usernamefld(self):
		usernamefld_a = self.cleaned_data['usernamefld']
		if not re.match("^[A-Za-z0-9_-]*$", usernamefld_a):
			raise forms.ValidationError("NOT A VALID USER NAME")
		if len(usernamefld_a) == 0 or len(usernamefld_a) > 50:
			raise forms.ValidationError("INPUT IS NOT ALLOWED")
		return usernamefld_a
		
	def clean_passwordfld(self):
		passwordfld_a = self.cleaned_data['passwordfld']
		if len(passwordfld_a) < 8 or len(passwordfld_a) > 100:
			raise forms.ValidationError("INPUT IS NOT ALLOWED")
		return passwordfld_a
		
	def clean_passwordconfirmfld(self):
		passwordconfirmfld_a = self.cleaned_data['passwordconfirmfld']
		if len(passwordconfirmfld_a) < 8 or len(passwordconfirmfld_a) > 100:
			raise forms.ValidationError("INPUT IS NOT ALLOWED")
		return passwordconfirmfld_a
		
	def clean_tradetokenfld(self):
		tradetokenfld_a = self.cleaned_data['tradetokenfld']
		if len(tradetokenfld_a) < 6 or len(tradetokenfld_a) > 50:
			raise forms.ValidationError("INPUT IS NOT ALLOWED")
		return tradetokenfld_a
		
	def clean_tradetokenconfirmfld(self):
		tradetokenconfirmfld_a = self.cleaned_data['tradetokenconfirmfld']
		if len(tradetokenconfirmfld_a) < 6 or len(tradetokenconfirmfld_a) > 50:
			raise forms.ValidationError("INPUT IS NOT ALLOWED")
		return tradetokenconfirmfld_a
		
	def clean(self):
		cleaned_data = super().clean()
		verifycodefld_b = cleaned_data.get("verifycodefld")
		usernamefld_b = cleaned_data.get("usernamefld")
		passwordfld_b = cleaned_data.get("passwordfld")
		passwordconfirmfld_b = cleaned_data.get("passwordconfirmfld")
		tradetokenfld_b = cleaned_data.get("tradetokenfld")
		tradetokenconfirmfld_b = cleaned_data.get("tradetokenconfirmfld")
		if passwordfld_b != passwordconfirmfld_b:
			raise forms.ValidationError("PASSWORD INCONSISTENT")
		if tradetokenfld_b != tradetokenconfirmfld_b:
			raise forms.ValidationError("TRADE PIN INCONSISTENT")
	
	
class withdraw_form(forms.Form):
	
	amountfld = forms.FloatField(label = 'Withdraw amount')
	tradetokenfld = forms.CharField(label = "Trade PIN", max_length = 50, widget = forms.PasswordInput)
	
	def clean_amountfld(self):
		amountfld_a = self.cleaned_data['amountfld']
		if amountfld_a < 0.01:
			raise forms.ValidationError("MINIMUM WITHDRAW AMOUNT IS 0.01 BTC")
		return amountfld_a
		
	def clean_tradetokenfld(self):
		tradetokenfld_a = self.cleaned_data['tradetokenfld']
		if len(tradetokenfld_a) < 6 or len(tradetokenfld_a) > 50:
			raise forms.ValidationError("INCORRECT TRADE PIN")
		return tradetokenfld_a
	
	
class changepw_form(forms.Form):
	
	newpwfld = forms.CharField(label = "New password, at least 8 characters", max_length = 100, widget = forms.PasswordInput)
	newpwconfirmfld = forms.CharField(label = "Confirm new password", max_length = 100, widget = forms.PasswordInput)
	tradetokenfld = forms.CharField(label = "Trade PIN", max_length = 50, widget = forms.PasswordInput)
	
	def clean_newpwfld(self):
		newpwfld_a = self.cleaned_data['newpwfld']
		if len(newpwfld_a) < 8 or len(newpwfld_a) > 100:
			raise forms.ValidationError("INPUT IS NOT ALLOWED")
		return newpwfld_a
	
	def clean_newpwconfirmfld(self):
		newpwconfirmfld_a = self.cleaned_data['newpwconfirmfld']
		if len(newpwconfirmfld_a) < 8 or len(newpwconfirmfld_a) > 100:
			raise forms.ValidationError("INPUT IS NOT ALLOWED")
		return newpwconfirmfld_a
	
	def clean_tradetokenfld(self):
		tradetokenfld_a = self.cleaned_data['tradetokenfld']
		if len(tradetokenfld_a) < 6 or len(tradetokenfld_a) > 50:
			raise forms.ValidationError("INPUT IS NOT ALLOWED")
		return tradetokenfld_a
	
	def clean(self):
		cleaned_data = super().clean()
		newpwfld_b = cleaned_data.get("newpwfld")
		newpwconfirmfld_b = cleaned_data.get("newpwconfirmfld")
		if newpwfld_b != newpwconfirmfld_b:
			raise forms.ValidationError("PASSWORD INCONSISTENT")
	
	
class order_form(forms.Form):
	
	orderamountfld = forms.IntegerField(label = "ORDER AMOUNT")
	orderpricefld = forms.FloatField(label = "ORDER PRICE")
	orderdirection = forms.ChoiceField(label = "ORDER TYPE", choices = ([('1', 'SELL'), ('2', 'BUY')]), widget = forms.RadioSelect())
	tradetokenfld = forms.CharField(label = "TRADE PIN", max_length = 50, widget = forms.PasswordInput)
	
	def clean_orderamountfld(self):
		orderamountfld_a = self.cleaned_data['orderamountfld']
		if orderamountfld_a <= 0:
			raise forms.ValidationError("ORDER AMOUNT IS NOT ALLOWED")
		return orderamountfld_a
	
	def clean_orderpricefld(self):
		orderpricefld_a = self.cleaned_data['orderpricefld']
		if orderpricefld_a <= 0 or orderpricefld_a >= 0.01:
			raise forms.ValidationError("THIS ORDER PRICE IS NOT REASONABLE")
		return orderpricefld_a
	
	def clean_tradetokenfld(self):
		tradetokenfld_a = self.cleaned_data['tradetokenfld']
		if len(tradetokenfld_a) < 6 or len(tradetokenfld_a) > 50:
			raise forms.ValidationError("INPUT IS NOT ALLOWED")
		return tradetokenfld_a
	
	
class cancel_form(forms.Form):
	
	targetidfld = forms.IntegerField(label = "ORDER ID")
	targettypefld = forms.ChoiceField(label = "ORDER TYPE", choices = ([('3', 'CANCEL SELL ORDER'), ('4', 'CANCEL BUY ORDER')]), widget = forms.RadioSelect())
	tradetokenfld = forms.CharField(label = "TRADE PIN", max_length = 50, widget = forms.PasswordInput)
	
	def clean_tradetokenfld(self):
		tradetokenfld_a = self.cleaned_data['tradetokenfld']
		if len(tradetokenfld_a) < 6 or len(tradetokenfld_a) > 50:
			raise forms.ValidationError("INPUT IS NOT ALLOWED")
		return tradetokenfld_a
	
	